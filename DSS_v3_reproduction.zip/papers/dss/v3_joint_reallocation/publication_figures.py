"""Render manuscript figures from completed experiments at their final print size."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
RUN=ROOT/'experiments/upgrade_v3/results/joint_v3_20261117'
OUT=HERE/'figures'
QA=HERE/'build/figure_qa'
sys.path.insert(0,str(Path.home()/'.codex/skills/nature-figure/scripts'))
try:
    from audit_panel_alignment import require_matplotlib_panel_alignment
except ImportError:
    require_matplotlib_panel_alignment = None

COLORS={'score_rematch':'#777777','mean_rematch':'#E69F00','additive_rematch':'#56B4E9',
        'greedy_rematch':'#222222','type_flow':'#0072B2','generic_lp':'#D55E00'}
LABELS={'score_rematch':'Score + rematching','mean_rematch':'Mean cost + rematching',
        'additive_rematch':'Row-column cost + rematching','greedy_rematch':'Greedy + rematching',
        'type_flow':'Type flow','generic_lp':'Network LP'}

def save(fig,name):
    fig.canvas.draw()
    if require_matplotlib_panel_alignment is not None:
        require_matplotlib_panel_alignment(fig,json_out=str(QA/f'{name}.alignment.json'),
            overlay_svg=str(QA/f'{name}.alignment.svg'),tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
    for ext in ['pdf','svg','png']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=400)
    plt.close(fig)

def main():
    OUT.mkdir(exist_ok=True);QA.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.titlesize':9,
        'axes.labelsize':8.5,'legend.fontsize':8,'axes.spines.top':False,'axes.spines.right':False,
        'svg.fonttype':'none','pdf.fonttype':42,'axes.linewidth':.7})
    d=pd.read_csv(RUN/'mechanisms/summary.csv').query('noise==0.04')
    fig,axes=plt.subplots(3,2,figsize=(6.4,6.35),sharex=True,sharey=True)
    fig.subplots_adjust(left=.105,right=.985,top=.95,bottom=.17,wspace=.18,hspace=.3)
    for i,family in enumerate(['compatibility','asymmetric','distance']):
        for j,balance in enumerate(['balanced','skewed']):
            ax=axes[i,j]
            for method in ['score_rematch','mean_rematch','additive_rematch','type_flow','greedy_rematch']:
                t=d[(d.balance==balance)&(d.family==family)&(d.method==method)].sort_values('strength')
                if method=='greedy_rematch':
                    ax.plot(t.strength,t.mean_net,marker='^',mfc='none',ms=6,lw=0,color=COLORS[method],label=LABELS[method])
                else:
                    ax.errorbar(t.strength,t.mean_net,yerr=1.96*t.mcse,marker='o',ms=3.5,lw=1.4,capsize=2,
                        color=COLORS[method],label=LABELS[method])
            family_name={'compatibility':'Compatibility','asymmetric':'Directional','distance':'Distance'}[family]
            ax.set_title(f'{chr(97+2*i+j)}  {family_name}, {balance}',loc='left')
            ax.axhline(0,color='black',lw=.5);ax.set_xticks([0,.5,1]);ax.set_ylim(-1.5,25)
    fig.supylabel('Conditional true net gain per 1,000',x=.01,fontsize=9)
    fig.supxlabel('Transition-cost strength',y=.115,fontsize=9)
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,.005),ncol=2,frameon=False,columnspacing=1.5)
    save(fig,'structural_value')

    r=pd.read_csv(RUN/'benchmark/runtime.csv')
    fig,axes=plt.subplots(1,3,figsize=(6.4,2.65),sharey=True)
    fig.subplots_adjust(left=.1,right=.98,top=.86,bottom=.25,wspace=.18)
    for idx,(ax,K) in enumerate(zip(axes,[3,9,25])):
        for method in ['type_flow','generic_lp']:
            t=r[(r.types==K)&(r.method==method)].groupby('n').seconds.agg(['mean','min','max'])
            ax.errorbar(t.index,t['mean'],yerr=np.array([t['mean']-t['min'],t['max']-t['mean']]),
                marker='o',ms=3.5,lw=1.3,capsize=2,color=COLORS[method],label=LABELS[method])
        ax.set_xscale('log');ax.set_yscale('log');ax.set_title(f'{chr(97+idx)}  {K} types',loc='left')
        ax.set_xticks([1000,10000,100000],['1k','10k','100k']);ax.xaxis.set_minor_locator(NullLocator())
    fig.supylabel('Solution time (seconds)',x=.01,fontsize=9);fig.supxlabel('Total records',y=.08,fontsize=9)
    fig.legend(*axes[0].get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.52,1.025),ncol=2,frameon=False)
    save(fig,'exact_solver_scaling')

    old=pd.read_csv(ROOT/'experiments/upgrade_v3/results/expanded_v3/coupling/replicates.csv')
    old=old[(old.n==6000)&(old.coupling==1)]
    t=old.groupby('method')[['gross_per_1000','cost_per_1000','true_net_per_1000']].mean().loc[['score_only','mean_cost','cost_flow']]
    fig,ax=plt.subplots(figsize=(6.4,3.2));fig.subplots_adjust(left=.105,right=.99,top=.9,bottom=.17)
    for off,col,color,label in [(-.24,'gross_per_1000','#999999','Gross benefit'),(0,'cost_per_1000','#E69F00','Transition cost'),(.24,'true_net_per_1000','#0072B2','Net gain')]:
        bars=ax.bar(np.arange(3)+off,t[col],width=.23,color=color,label=label)
        ax.bar_label(bars,fmt='%.2f',fontsize=8,padding=3)
    ax.set_xticks(range(3),['Score + rematching','Mean cost + rematching','Type flow'])
    ax.set_ylabel('Benefit-equivalent units per 1,000');ax.set_ylim(0,28.8)
    ax.legend(loc='upper center',frameon=False,ncol=3,bbox_to_anchor=(.5,1.12))
    save(fig,'value_decomposition')

    fig,axes=plt.subplots(1,3,figsize=(6.4,2.4))
    fig.subplots_adjust(left=.095,right=.995,top=.82,bottom=.2,wspace=.29)
    ax=axes[0];cost=np.array([[.01,.02],[.02,.18]])
    ax.imshow(cost,cmap='Blues',vmin=0,vmax=.2,aspect='auto')
    for i in range(2):
        for j in range(2):ax.text(j,i,f'{cost[i,j]:.2f}',ha='center',va='center',color='white' if cost[i,j]>.1 else 'black')
    ax.set_xticks([0,1],['I1','I2']);ax.set_yticks([0,1],['E1','E2']);ax.set_title('a  Pair cost',loc='left')
    for ax,edges,title in [(axes[1],[(0,0)],'b  Greedy: 0.19'),(axes[2],[(0,1),(1,0)],'c  Joint: 0.34')]:
        ax.set_xlim(-.5,1.5);ax.set_ylim(-.4,1.4);ax.axis('off');ax.set_title(title,loc='left')
        for i,score in enumerate([.20,.18]):
            ax.scatter(0,1-i,s=120,color='#0072B2');ax.text(-.13,1-i,f'{score:.2f}',ha='right',va='center',fontsize=8)
            ax.scatter(1,1-i,s=120,color='#999999');ax.text(1.13,1-i,'0',ha='left',va='center',fontsize=8)
        for i,j in edges:ax.annotate('',xy=(.9,1-j),xytext=(.1,1-i),arrowprops={'arrowstyle':'->','lw':1.4,'color':'#0072B2'})
        ax.text(0,-.35,'E',ha='center');ax.text(1,-.35,'I',ha='center')
    save(fig,'residual_exchange_example')
    print('Four figures exported as PDF, SVG and PNG at 6.4 inches.')

if __name__=='__main__':main()
