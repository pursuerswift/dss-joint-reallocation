"""Network architecture and paired conflict-frontier evidence, in editable vector form."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
RUN=ROOT/'experiments/upgrade_v3/results/revision_v3_20261117/conflict'
OUT=HERE/'figures';QA=HERE/'build/figure_qa'
sys.path.insert(0,str(Path.home()/'.codex/skills/nature-figure/scripts'))
try:
    from audit_panel_alignment import require_matplotlib_panel_alignment
except ImportError:
    require_matplotlib_panel_alignment = None


def save(fig,name,multipanel=False):
    fig.canvas.draw()
    if multipanel and require_matplotlib_panel_alignment is not None:
        require_matplotlib_panel_alignment(fig,json_out=str(QA/f'{name}.alignment.json'),
            overlay_svg=str(QA/f'{name}.alignment.svg'),tolerance_pt=1.5,
            gutter_tolerance_pt=1.5,strict=True)
    fig.savefig(OUT/f'{name}.pdf')
    fig.savefig(OUT/f'{name}.svg')
    fig.savefig(OUT/f'{name}.png',dpi=600)
    plt.close(fig)


def network():
    fig,ax=plt.subplots(figsize=(6.4,3.7))
    fig.subplots_adjust(left=.02,right=.98,top=.98,bottom=.02)
    ax.set(xlim=(0,6.4),ylim=(0,3.7));ax.axis('off')
    src=(.48,1.85);sink=(5.92,1.85)
    left=[(2.05,y) for y in [2.55,1.85,1.15]]
    right=[(4.35,y) for y in [2.55,1.85,1.15]]
    def arrow(a,b,color='#777777',rad=0,ls='-',shrink=15):
        ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=9,lw=.9,
            color=color,connectionstyle=f'arc3,rad={rad}',linestyle=ls,
            shrinkA=shrink,shrinkB=shrink,zorder=1))
    for a in left:arrow(src,a)
    for b in right:arrow(b,sink)
    for a in left:
        for b in right:arrow(a,b,color='#adb8c1',shrink=15)
    arrow(right[1],left[1],color='#0072B2',rad=.18,ls='--')
    # Bypass is a polyline above the type layers, with its own capacity/cost label.
    ax.plot([src[0],src[0],sink[0]],[2.02,3.42,3.42],color='#777777',lw=.9)
    arrow((sink[0],3.42),(sink[0],2.03),shrink=0)
    ax.text(3.2,3.52,'Unused budget: (r, 0)',ha='center',va='bottom',fontsize=8.5)
    for pos,label,col in [(src,'S','#ededed'),(sink,'T','#ededed')]+[(p,l,'#e5f2f9') for p,l in zip(left,[r'$E_1$',r'$E_a$',r'$E_K$'])]+[(p,l,'#fff0dd') for p,l in zip(right,[r'$I_1$',r'$I_b$',r'$I_K$'])]:
        ax.add_patch(Circle(pos,.18,facecolor=col,edgecolor='#444444',lw=.8,zorder=2))
        ax.text(*pos,label,ha='center',va='center',fontsize=9,zorder=3)
    ax.text(.48,.62,'Source\nsupply r',ha='center',fontsize=8.5)
    ax.text(5.92,.62,'Sink\ndemand r',ha='center',fontsize=8.5)
    ax.text(2.05,.62,'K entrant types',ha='center',fontsize=8.5)
    ax.text(4.35,.62,'K incumbent types',ha='center',fontsize=8.5)
    ax.text(1.20,2.93,r'$(1,-s_i)$',ha='center',fontsize=9)
    ax.text(3.20,2.93,r'$(r,\Gamma_{ab})$',ha='center',fontsize=9)
    ax.text(5.10,2.93,r'$(1,s_j)$',ha='center',fontsize=9)
    ax.text(3.2,.12,r'Reverse type arc: $(z_{ab},-\Gamma_{ab})$; labels = (capacity, cost)',
            ha='center',fontsize=8.5,color='#0072B2')
    save(fig,'network_architecture')


def conflict():
    d=pd.read_csv(RUN/'replicates.csv')
    d=d[(d.family=='specialist_flexible')&(d.n==8000)&(d.types==12)&(d.strength==1)]
    fig,axes=plt.subplots(1,2,figsize=(6.4,3.15))
    fig.subplots_adjust(left=.09,right=.985,bottom=.20,top=.81,wspace=.36)
    for method,color,marker in [('greedy_rematch','#777777','s'),('type_flow','#0072B2','o')]:
        t=d[(d.noise==0)&(d.method==method)].groupby('cap_share').true_net_per_1000.agg(['mean','std','count'])
        axes[0].errorbar(t.index,t['mean'],yerr=1.96*t['std']/np.sqrt(t['count']),color=color,
            marker=marker,ms=4,capsize=2,lw=1.5,label='Greedy + rematching' if method=='greedy_rematch' else 'Type flow')
    axes[0].set(xlabel='Cap / incumbent count',ylabel='True net gain per 1,000',xticks=[.25,.5,.75,1])
    axes[0].set_title('a  Budget frontier, known benefits',loc='left',pad=10)
    full=d[d.cap_share==1].pivot(index=['noise','rep'],columns='method',values=['true_net_per_1000','predicted_net_per_1000'])
    for j,(metric,label,color) in enumerate([('predicted_net_per_1000','Score objective','#D55E00'),('true_net_per_1000','True value','#0072B2')]):
        delta=full[metric]['type_flow']-full[metric]['greedy_rematch']
        t=delta.groupby('noise').agg(['mean','std','count'])
        axes[1].errorbar(np.arange(2)+(j-.5)*.14,t['mean'],yerr=1.96*t['std']/np.sqrt(t['count']),
            fmt='o',ms=5,capsize=3,color=color,label=label)
    axes[1].axhline(0,color='#aaaaaa',lw=.7)
    axes[1].set(xlabel='Score-noise SD',ylabel='Exact minus greedy per 1,000',xticks=[0,1],xticklabels=['0','.04'],xlim=(-.4,1.4))
    axes[1].set_title('b  Full-cap paired value differences',loc='left',pad=10)
    for idx,ax in enumerate(axes):
        ax.legend(loc='lower right' if idx==0 else 'center right',frameon=False,fontsize=7)
        ax.spines[['top','right']].set_visible(False)
    save(fig,'conflict_frontier',True)


if __name__=='__main__':
    OUT.mkdir(exist_ok=True);QA.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':8,'axes.titlesize':8,
        'axes.labelsize':8,'legend.fontsize':7,'pdf.fonttype':42,'svg.fonttype':'none',
        'axes.linewidth':.7})
    network();conflict()
