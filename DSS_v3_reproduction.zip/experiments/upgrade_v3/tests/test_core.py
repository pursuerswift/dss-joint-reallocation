import itertools
import unittest
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.stats import norm
from upgrade.flow import Plan, retention, solve_path, topk, rematch
from upgrade.inference import aipw, support_width, evaluate, certify, choose, required_n
from upgrade.policies import make_menu, METHODS
from upgrade.simulation import instance


def brute(score, base, types, gamma, cap, variance, penalty):
    e, l = np.flatnonzero(~base), np.flatnonzero(base)
    best = 0.
    for m in range(1,min(cap,len(e),len(l))+1):
        for E in itertools.combinations(e,m):
            for L in itertools.combinations(l,m):
                E,L=np.array(E),np.array(L)
                C=gamma[types[E]][:,types[L]]
                a,b=linear_sum_assignment(C)
                value=score[E].sum()-score[L].sum()-C[a,b].sum()-penalty*(variance[E].sum()+variance[L].sum())
                best=max(best,value)
    return best


class CoreTests(unittest.TestCase):
    def test_random_exhaustive_flow_and_penalty(self):
        rng=np.random.default_rng(707)
        for _ in range(35):
            s=rng.normal(size=8); b=np.arange(8)>=4
            ty=rng.integers(0,4,8); g=rng.uniform(0,.8,(4,4)); v=rng.uniform(0,2,8)
            eta=float(rng.uniform(0,.3))
            paths=solve_path(s,b,ty,g,[0,1,2,3,4],v,eta)
            for cap,p in paths.items():
                w=p.weights(8)
                actual=w@s-p.cost-eta*((w*w)@v)
                self.assertAlmostEqual(actual,brute(s,b,ty,g,cap,v,eta),places=8)
                self.assertEqual(int((b+w).sum()),4)
                self.assertTrue(np.isin(b+w,[0,1]).all())
                self.assertLessEqual(p.m,cap)
                self.assertTrue(np.all(np.diff(p.marginals)<=1e-8))

    def test_stop_before_negative_and_zero(self):
        for cost, expected in [(.2,0),(.1,0),(.05,1)]:
            p=solve_path([.1,0],[0,1],[0,0],np.array([[cost]]),[1])[1]
            self.assertEqual(p.m,expected)

    def test_residual_rematching(self):
        s=np.array([10.,10.,0.,0.]);b=np.array([0,0,1,1],bool)
        p=solve_path(s,b,np.array([0,1,0,1]),np.array([[0.,1.],[1.,10.]]),[1,2])
        self.assertAlmostEqual(p[1].cost,0)
        self.assertAlmostEqual(p[2].cost,2)
        self.assertEqual(set(map(tuple,p[2].pairs)),{(0,3),(1,2)})

    def test_evaluator_global_index_regression(self):
        phi=np.array([100.,2.,7.,-5.,4.])
        p=Plan(np.array([[1,3],[4,2]]),.6)
        e=evaluate(p,phi,1.)
        self.assertAlmostEqual(e['gross'],(2+4+5-7)/5)
        self.assertAlmostEqual(e['net'],(2+4+5-7-.6-1)/5)
        self.assertEqual(evaluate(retention(),phi,100)['net'],0)

    def test_aipw_randomization_expectation_and_range(self):
        mu=np.array([[.1,.7,.4],[.4,.3,.2]])
        true=np.array([[.2,.6,.5],[.6,.5,.7]])
        prop=np.array([.2,.3,.5]); expected=np.zeros(2); possibilities=[]
        for a in range(3):
            for y in [0,1]:
                phi=aipw(np.full(2,a),np.full(2,y),mu,prop)
                expected+=prop[a]*np.where(y,true[:,a],1-true[:,a])*phi
                possibilities.append(phi)
        np.testing.assert_allclose(expected,true[:,1]-true[:,0])
        np.testing.assert_allclose(support_width(mu,prop),np.ptp(possibilities,axis=0))

    def test_net_frontier_fixed_and_variable_cost(self):
        a=(2.5+norm.ppf(.8))*.3
        n0=required_n(.002,0,.3,2.5)
        n1=required_n(.002,.0015,.3,2.5)
        self.assertLessEqual(abs(n1-16*n0),16)
        n=required_n(.004,.001,.3,2.5,fixed_cost=7)
        self.assertGreaterEqual(.003*n-a*np.sqrt(n)-7,-1e-9)
        self.assertLess(.003*(n-1)-a*np.sqrt(n-1)-7,0)
        self.assertTrue(np.isinf(required_n(.001,.002,.3,2.5)))

    def test_retention_constant_data_and_multiplicity(self):
        p=Plan(np.array([[0,1]]),0,'p','cost_flow')
        rows=certify([retention(),p,p],np.zeros(10),np.ones(10)*4,draws=100)
        self.assertEqual(rows[1]['unique_menu'],1)
        self.assertEqual(choose(rows)['key'],'retain')
        self.assertLess(rows[1]['lcb_hoeffding'],0)
        self.assertTrue(np.isneginf(rows[1]['lcb_max_t']))

    def test_strong_baseline_rematch(self):
        ty=np.array([0,1,0,1]); g=np.array([[10.,1.],[2.,9.]])
        p=rematch([0,1],[2,3],ty,g)
        self.assertEqual(p.cost,3)

    def test_menu_validity_and_no_label_argument(self):
        rng=np.random.default_rng(1);n=80
        s=rng.normal(size=n);b=topk(rng.normal(size=n),np.arange(n),.25)
        ty=rng.integers(0,3,n);g=rng.uniform(0,.2,(3,3));v=rng.uniform(.1,2,n)
        plans=make_menu(s,b,ty,g,v,[.05,.25,1.],[.25,1,4])
        self.assertEqual(len(plans),1+len(METHODS)*3)
        self.assertEqual(len(set(p.key for p in plans)),len(plans))
        for p in plans:
            w=p.weights(n)
            self.assertEqual(w.sum(),0)
            self.assertTrue(np.isin(b+w,[0,1]).all())
            self.assertAlmostEqual(p.cost,sum(g[ty[i],ty[j]] for i,j in p.pairs))

    def test_dgp_probabilities_and_harm_oracle(self):
        for regime in ['equal_value','harm','diffuse','concentrated','variance_tradeoff','pair_cost']:
            d=instance(regime,30000,819,.04,.2)
            self.assertTrue(((d['mu']>=0)&(d['mu']<=1)).all())
            if regime=='harm':
                self.assertGreaterEqual(d['tau'][d['base']].min(),d['tau'][~d['base']].max())
            if regime=='equal_value':
                self.assertEqual(d['gamma'].sum(),0.)

    def test_duplicate_integer_caps_have_distinct_keys(self):
        plans=make_menu(np.array([1.,2.,3.]),np.array([0,0,1],bool),np.array([0,0,0]),
                        np.array([[0.]]),np.ones(3),[.05,.25,1.],[1.])
        self.assertEqual(len(set(p.key for p in plans)),len(plans))

    def test_design_z_zero_contains_cost_flow_optimum(self):
        rng=np.random.default_rng(55);n=40
        s=rng.normal(size=n);b=topk(rng.normal(size=n),np.arange(n),.2)
        ty=rng.integers(0,3,n);g=rng.uniform(0,.5,(3,3));v=rng.uniform(.1,2,n)
        plans=make_menu(s,b,ty,g,v,[.25,1.],[.25,1,4],design_z=0)
        bykey={p.key:p for p in plans}
        for cap in [.25,1.]:
            a,c=bykey[f'evidence_flow:cap{cap:g}'],bykey[f'cost_flow:cap{cap:g}']
            self.assertAlmostEqual(a.weights(n)@s-a.cost,c.weights(n)@s-c.cost)


if __name__=='__main__': unittest.main()
