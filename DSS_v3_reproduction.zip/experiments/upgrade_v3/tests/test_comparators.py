import unittest
import numpy as np
from upgrade.comparators import generic_lp,greedy_rematch
from upgrade.flow import solve_path
from tests.test_core import brute


class ComparatorTests(unittest.TestCase):
    def test_independent_lp_matches_enumeration(self):
        rng=np.random.default_rng(20261117)
        for _ in range(24):
            n=9;s=rng.normal(size=n);b=np.arange(n)<4;t=rng.integers(0,4,n)
            g=rng.uniform(0,1,(4,4))
            for cap in [0,1,2,4]:
                p=generic_lp(s,b,t,g,cap)
                val=p.weights(n)@s-p.cost
                self.assertAlmostEqual(val,brute(s,b,t,g,cap,np.zeros(n),0),places=7)
                self.assertTrue(np.isin(b.astype(int)+p.weights(n),[0,1]).all())
                self.assertLessEqual(p.m,cap)
                q=greedy_rematch(s,b,t,g,cap)
                self.assertLessEqual(q.weights(n)@s-q.cost,val+1e-8)

    def test_residual_reassignment_adds_value_beyond_greedy(self):
        s=np.array([.2,.18,0.,0.]);b=np.array([0,0,1,1],bool)
        t=np.array([0,1,0,1]);g=np.array([[.01,.02],[.02,.18]])
        p=greedy_rematch(s,b,t,g,2);q=solve_path(s,b,t,g,[2])[2]
        self.assertEqual(p.m,1);self.assertEqual(q.m,2)
        self.assertAlmostEqual(p.weights(4)@s-p.cost,.19)
        self.assertAlmostEqual(q.weights(4)@s-q.cost,.34)
        path=solve_path(s,b,t,g,[0,1,2])
        self.assertEqual(path[0].reverse_augmentations,0)
        self.assertEqual(path[1].reverse_augmentations,0)
        self.assertEqual(path[2].reverse_augmentations,1)
        self.assertEqual(path[2].reverse_arc_traversals,1)


if __name__=='__main__':unittest.main()
