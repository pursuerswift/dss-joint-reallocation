"""Empirical design-penalty response curves using existing fitted predictions.

This exploratory mechanism experiment reports every fixed penalty, without
selecting a penalty from test outcomes or changing the primary experiment.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from upgrade.policies import make_menu,cost_scenario
from upgrade.inference import design_variance,evaluate,certify,choose,support_width

HERE=Path(__file__).resolve().parent
PENALTIES=[0.,.5,1.,1.5,2.5]


def run(root):
    cfg=json.loads((root/'empirical/config.json').read_text())
    dest=root/'penalty_path';dest.mkdir(exist_ok=True)
    scenarios=[s for s in cfg['empirical']['cost_scenarios'] if s['name'] in ['zero','pair_low']]
    protocol=dict(penalties=PENALTIES,scenarios=scenarios,caps=cfg['caps'],
                  role='exploratory mechanism experiment; all penalty settings reported',
                  source_run=root.name,selection='fixed penalties; no test-outcome tuning')
    (dest/'design.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    rows=[];decisions=[]
    for dataset in cfg['empirical']['datasets']:
        for seed in cfg['empirical']['split_seeds']:
            folder=root/'empirical'/f'{dataset}_{seed}'
            info=json.loads((folder/'design.json').read_text())
            prop=info['propensity'];K=info['type_definition']['K']
            with np.load(folder/'evaluation_arrays.npz') as arrays:
                for scenario in scenarios:
                    gamma=cost_scenario(K,scenario['base'],scenario['coupling'],cfg['seed'])
                    for z in PENALTIES:
                        selected=None
                        for role in ['gate','test']:
                            phi=arrays[f'{role}_phi'];mu=arrays[f'{role}_mu']
                            plans=make_menu(arrays[f'{role}_score'],arrays[f'{role}_base'],
                                arrays[f'{role}_types'],gamma,design_variance(mu,prop),
                                cfg['caps'],cfg['eta_factors'],z)
                            if role=='gate':
                                bounds=certify(plans,phi,support_width(mu,prop),cfg['alpha'],
                                               cfg['gaussian_draws'],seed,scenario['fixed'])
                                selected=choose(bounds,'max_t','evidence_flow')
                            for p in plans:
                                if p.method!='evidence_flow': continue
                                value=evaluate(p,phi,scenario['fixed'])
                                rows.append(dict(dataset=dataset,seed=seed,scenario=scenario['name'],
                                    penalty=z,role=role,cap=p.cap,**value,
                                    lower=value['net']-1.96*value['se'],upper=value['net']+1.96*value['se']))
                            if role=='test':
                                chosen=next(p for p in plans if p.key==selected['key'])
                                value=evaluate(chosen,phi,scenario['fixed'])
                                decisions.append(dict(dataset=dataset,seed=seed,scenario=scenario['name'],
                                    penalty=z,key=chosen.key,gate_net=selected['net'],gate_lcb=selected['lcb_max_t'],
                                    test_net=value['net'],test_exchanges=value['exchanges']))
            print(f'penalty path {dataset} seed={seed} complete',flush=True)
    pd.DataFrame(rows).to_csv(dest/'candidate_values.csv',index=False)
    pd.DataFrame(decisions).to_csv(dest/'decision_values.csv',index=False)
    plot(pd.DataFrame(rows),dest)


def plot(frame,dest):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    datasets=list(frame.dataset.unique())
    for scenario in frame.scenario.unique():
        d=frame[(frame.role=='test')&(frame.cap==1)&(frame.scenario==scenario)]
        fig,axes=plt.subplots(len(datasets),2,figsize=(10,8),constrained_layout=True)
        for i,ds in enumerate(datasets):
            for seed,g in d[d.dataset==ds].groupby('seed'):
                g=g.sort_values('penalty')
                axes[i,0].plot(g.penalty,g.net*1000,marker='o',label=str(seed))
                axes[i,1].plot(g.penalty,g.turnover*100,marker='o',label=str(seed))
            for ax in axes[i]:
                ax.set_title(ds);ax.set_xlabel('Design variance penalty');ax.set_xticks(PENALTIES)
            axes[i,0].axhline(0,color='black',lw=.6)
            axes[i,0].set_ylabel('Candidate net gain / 1,000')
            axes[i,1].set_ylabel('Exchanges / population (%)')
        axes[0,1].legend(title='Split seed',frameon=False)
        fig.suptitle(f'Penalty response | {scenario} | held-out cohort | full cap')
        for ext in ['png','svg']: fig.savefig(dest/f'penalty_response_{scenario}.{ext}',dpi=180)
        plt.close(fig)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run-id',default='expanded_v3')
    args=parser.parse_args()
    with threadpool_limits(limits=1): run(HERE/'results'/args.run_id)
