"""Fit -> tune -> cost-aware gate -> freeze -> independent cohort evaluation."""
import json
import time
import numpy as np
import pandas as pd
from .data import load,fitted_predictions,fit_types,apply_types,reveal_test
from .flow import topk
from .inference import aipw,support_width,design_variance,certify,choose,evaluate,required_n
from .policies import make_menu,cost_scenario,METHODS


def run(cfg,dest,resume=False):
    dest.mkdir(parents=True,exist_ok=True)
    ecfg=cfg['empirical'];start=time.perf_counter()
    for dataset in ecfg['datasets']:
        for seed in ecfg['split_seeds']:
            out=dest/f'{dataset}_{seed}';out.mkdir(exist_ok=True)
            if resume and (out/'complete.json').exists(): continue
            parts,prop,cats,sources=load(dataset,seed,ecfg)
            pred,selection=fitted_predictions(parts,prop,cats,ecfg,seed,cfg['quota'])
            typespec=fit_types(dataset,parts['train'].x)
            info=dict(dataset=dataset,split_seed=seed,source_manifest=sources,propensity=prop.tolist(),
                type_definition=typespec,model_selection=selection,
                roles={k:dict(n=len(c.ids)) for k,c in parts.items()},
                provenance='historical randomized field experiment' if dataset!='promotion' else 'educational promotional benchmark')
            (out/'design.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
            np.savez_compressed(out/'split_ids.npz',**{k:c.ids for k,c in parts.items()})
            print(f'empirical {dataset} seed={seed} fitted {selection["challenger"]} elapsed={time.perf_counter()-start:.1f}s',flush=True)
            gate=parts['gate'];pg=pred['gate'];types=apply_types(gate.x,typespec)
            base=topk(pg['response'],gate.ids,cfg['quota'])
            phi=aipw(gate.a,gate.y,pg['mu'],prop)
            widths=support_width(pg['mu'],prop);variance=design_variance(pg['mu'],prop)
            gate_rows,choices,frontiers=[],[],[]
            for scenario in ecfg['cost_scenarios']:
                gamma=cost_scenario(typespec['K'],scenario['base'],scenario['coupling'],cfg['seed'])
                plans=make_menu(pg['score'],base,types,gamma,variance,cfg['caps'],cfg['eta_factors'],cfg['design_z'])
                rows=certify(plans,phi,widths,cfg['alpha'],cfg['gaussian_draws'],seed,scenario['fixed'])
                bykey={p.key:p for p in plans}
                for row in rows:
                    gate_rows.append(dict(dataset=dataset,seed=seed,scenario=scenario['name'],**row))
                    p=bykey[row['key']]
                    if not p.m: continue
                    for target in [.001,.002,.005,.01]:
                        frontiers.append(dict(dataset=dataset,seed=seed,scenario=scenario['name'],key=row['key'],
                            assumed_gross_target=target,variable_cost=p.cost/len(phi),fixed_total_cost=scenario['fixed'],
                            sigma=row['se']*np.sqrt(len(phi)),critical=row['critical'],
                            required_n=required_n(target,p.cost/len(phi),row['se']*np.sqrt(len(phi)),row['critical'],fixed_cost=scenario['fixed']),
                            interpretation='conditional planning at stated gross target; not observed certification'))
                for rule in ['max_t','bonferroni','hoeffding']:
                    for method in METHODS+['combined']:
                        selected=choose(rows,rule,None if method=='combined' else method)
                        choices.append(dict(scenario=scenario['name'],rule=rule,pipeline=method,key=selected['key'],
                            gate_net=selected['net'],gate_lcb=selected[f'lcb_{rule}'],gate_exchanges=selected['exchanges']))
            freeze=out/'gate_choices_before_test.json'
            freeze.write_text(json.dumps(choices,indent=2),encoding='utf-8')
            pd.DataFrame(gate_rows).to_csv(out/'gate_candidates.csv',index=False)
            pd.DataFrame(frontiers).to_csv(out/'net_power_frontier.csv',index=False)
            # Test labels become available to evaluation only after all gate decisions.
            test=parts['test'];pt=pred['test'];yt=reveal_test(dataset,test,freeze)
            phit=aipw(test.a,yt,pt['mu'],prop)
            bt=topk(pt['response'],test.ids,cfg['quota']);tt=apply_types(test.x,typespec)
            vt=design_variance(pt['mu'],prop)
            test_rows,decisions,contrasts=[],[],[]
            for scenario in ecfg['cost_scenarios']:
                gamma=cost_scenario(typespec['K'],scenario['base'],scenario['coupling'],cfg['seed'])
                plans=make_menu(pt['score'],bt,tt,gamma,vt,cfg['caps'],cfg['eta_factors'],cfg['design_z'])
                bykey={p.key:p for p in plans}
                for p in plans:
                    e=evaluate(p,phit,scenario['fixed'])
                    test_rows.append(dict(dataset=dataset,seed=seed,scenario=scenario['name'],key=p.key,
                        method=p.method,cap=p.cap,**e,lower=e['net']-1.96*e['se'],upper=e['net']+1.96*e['se'],
                        role='predefined candidate diagnostic; not used to reopen gate'))
                for dec in [d for d in choices if d['scenario']==scenario['name']]:
                    e=evaluate(bykey[dec['key']],phit,scenario['fixed'])
                    decisions.append(dict(dataset=dataset,seed=seed,**dec,test_net=e['net'],test_se=e['se'],
                        test_lower=e['net']-1.96*e['se'],test_upper=e['net']+1.96*e['se'],test_exchanges=e['exchanges']))
                # Predeclared paired algorithm comparisons at each cap, with full outputs.
                for cap in cfg['caps']:
                    pa=bykey[f'evidence_flow:cap{cap:g}'];ea=evaluate(pa,phit,scenario['fixed'])
                    for method in METHODS[:-1]:
                        pb=bykey[f'{method}:cap{cap:g}'];eb=evaluate(pb,phit,scenario['fixed'])
                        dz=(pa.weights(len(phit))-pb.weights(len(phit)))*phit
                        se=float(dz.std(ddof=1)/np.sqrt(len(dz)));diff=ea['net']-eb['net']
                        contrasts.append(dict(dataset=dataset,seed=seed,scenario=scenario['name'],cap=cap,comparator=method,
                            net_difference=diff,se=se,lower=diff-1.96*se,upper=diff+1.96*se,
                            inference='pointwise diagnostic, not simultaneous gate evidence'))
            pd.DataFrame(test_rows).to_csv(out/'test_candidates.csv',index=False)
            pd.DataFrame(decisions).to_csv(out/'frozen_decision_test.csv',index=False)
            pd.DataFrame(contrasts).to_csv(out/'test_paired_contrasts.csv',index=False)
            np.savez_compressed(out/'evaluation_arrays.npz',gate_ids=gate.ids,gate_phi=phi,gate_score=pg['score'],
                gate_mu=pg['mu'],gate_types=types,gate_base=base,test_ids=test.ids,test_phi=phit,
                test_score=pt['score'],test_mu=pt['mu'],test_types=tt,test_base=bt)
            (out/'complete.json').write_text(json.dumps(dict(status='complete',choices_file=freeze.name,
                n_gate=len(gate.ids),n_test=len(test.ids),gate_candidate_rows=len(gate_rows),
                frozen_decision_rows=len(decisions))),encoding='utf-8')
            print(f'empirical {dataset} complete elapsed={time.perf_counter()-start:.1f}s',flush=True)
    for name in ['gate_candidates','net_power_frontier','test_candidates','frozen_decision_test','test_paired_contrasts']:
        files=sorted(dest.glob(f'*/{name}.csv'))
        if files: pd.concat([pd.read_csv(f) for f in files],ignore_index=True).to_csv(dest/f'{name}.csv',index=False)
