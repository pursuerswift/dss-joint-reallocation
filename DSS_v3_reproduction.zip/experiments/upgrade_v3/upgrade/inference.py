"""Paired net-value inference; design proxies never replace gate evidence."""
import numpy as np
from scipy.stats import norm


def aipw(a, y, mu, propensity, active=1):
    a, y, mu, p = np.asarray(a, int), np.asarray(y, float), np.asarray(mu, float), np.asarray(propensity, float)
    if mu.shape != (len(y), len(p)) or (p <= 0).any() or not np.isclose(p.sum(), 1):
        raise ValueError('Invalid nuisance shape or randomization probabilities')
    if not np.isin(y, [0, 1]).all() or (mu < 0).any() or (mu > 1).any():
        raise ValueError('This evaluator requires binary outcomes and probabilities')
    return (mu[:, active]-mu[:, 0] + (a == active)*(y-mu[:, active])/p[active]
            - (a == 0)*(y-mu[:, 0])/p[0])


def support_width(mu, propensity, active=1):
    """Exact conditional range over all assignment arms and binary outcomes."""
    mu, p = np.asarray(mu), np.asarray(propensity)
    residuals = [-mu[:, active]/p[active], (1-mu[:, active])/p[active],
                 mu[:, 0]/p[0], -(1-mu[:, 0])/p[0]]
    if len(p) > 2: residuals.append(np.zeros(len(mu)))
    a = np.asarray(residuals)
    return np.ptp(a, axis=0)


def design_variance(mu, propensity, active=1):
    p = np.asarray(propensity)
    return mu[:, active]*(1-mu[:, active])/p[active] + mu[:, 0]*(1-mu[:, 0])/p[0]


def evaluate(plan, phi, fixed_cost=0.0):
    n = len(phi)
    w = plan.weights(n)
    z = w*phi
    charge = (plan.cost + fixed_cost)/n if plan.m else 0.0
    return dict(gross=float(z.mean()), cost=charge, net=float(z.mean()-charge),
                se=float(z.std(ddof=1)/np.sqrt(n)), turnover=plan.m/n, exchanges=plan.m)


def certify(plans, phi, widths, alpha=.05, draws=2048, seed=1, fixed_cost=0.0):
    """Shared simultaneous bounds for a finite X/score-defined menu.

    Gaussian max-t is a working approximation. Conditional Hoeffding is the
    finite-sample comparator under independent randomized records given X.
    Exact duplicate assignment vectors share a gross-value bound.
    """
    n = len(phi)
    W = np.column_stack([p.weights(n) for p in plans])
    U, inverse = np.unique(W, axis=1, return_inverse=True)
    Z = U*np.asarray(phi)[:, None]
    means, se = Z.mean(0), Z.std(0, ddof=1)/np.sqrt(n)
    nonzero = np.any(U != 0, axis=0)
    active = nonzero & (se > 1e-14)
    M = max(int(nonzero.sum()), 1)
    critical = norm.ppf(1-alpha)
    if active.any():
        zz = Z[:, active] - means[active]
        cov = zz.T @ zz/(n*(n-1))
        corr = cov/np.outer(se[active], se[active])
        corr = (corr+corr.T)/2
        eig, vec = np.linalg.eigh(corr)
        if eig.min() < -1e-7: raise ArithmeticError('Non-PSD covariance')
        samples = np.random.default_rng(seed).standard_normal((draws, active.sum())) @ (vec*np.sqrt(np.maximum(eig,0))).T
        critical = max(float(np.quantile(samples.max(1), 1-alpha, method='higher')), norm.ppf(1-alpha))
    cb = norm.ppf(1-alpha/M)
    hoeff = np.sqrt(np.sum((U*np.asarray(widths)[:, None])**2, axis=0)*np.log(M/alpha)/2)/n
    output = []
    for j, plan in enumerate(plans):
        d = evaluate(plan, phi, fixed_cost)
        u = inverse[j]
        lowers = dict(max_t=d['net']-critical*se[u], bonferroni=d['net']-cb*se[u],
                      hoeffding=d['net']-hoeff[u])
        if plan.m and se[u] <= 1e-14:
            lowers['max_t'] = lowers['bonferroni'] = -np.inf
        output.append(dict(key=plan.key, method=plan.method, cap=plan.cap, eta=plan.eta,
                           **d, **{f'lcb_{k}': float(v) for k,v in lowers.items()},
                           critical=float(critical), unique_menu=M))
    return output


def choose(rows, rule='max_t', method=None):
    eligible = [r for r in rows if r['method'] == 'retain' or method is None or r['method'] == method]
    best = max(eligible, key=lambda r:(r[f'lcb_{rule}'], -r['exchanges']))
    return best if best[f'lcb_{rule}'] > 0 else next(r for r in rows if r['method'] == 'retain')


def required_n(gross_target, variable_cost, sigma, critical, power=.8, fixed_cost=0.0):
    """Normal-working sample size for positive NET gain, fixed turnover mix.

    Solve (gross-variable)*n - (critical+z_power)*sigma*sqrt(n) - C >= 0.
    Costs are in outcome units; total fixed C is paid once per target cohort.
    """
    if sigma < 0 or fixed_cost < 0 or not 0 < power < 1:
        raise ValueError('Invalid planning inputs')
    margin = gross_target-variable_cost
    if margin <= 0: return np.inf
    a = (critical+norm.ppf(power))*sigma
    root = (a+np.sqrt(a*a+4*margin*fixed_cost))/(2*margin)
    return float(max(2, np.ceil(root*root)))
