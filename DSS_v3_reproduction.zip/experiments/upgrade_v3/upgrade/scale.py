"""Actual total population, cap and completed exchanges are distinct outputs."""
import time
import numpy as np
import pandas as pd
from .flow import topk,solve_path
from .policies import cost_scenario


def run(cfg,dest):
    rows=[]
    for n in cfg['scale']['total_records']:
        for K in cfg['scale']['types']:
            rng=np.random.default_rng(np.random.SeedSequence([cfg['seed'],n,K]))
            s=rng.normal(0,.1,n);base=topk(rng.normal(size=n),np.arange(n),cfg['quota'])
            types=rng.integers(0,K,n);gamma=cost_scenario(K,.005,.02,cfg['seed'])
            cap=int(base.sum()*cfg['scale']['cap_share_of_places'])
            for rep in range(cfg['scale']['repetitions']):
                start=time.perf_counter();p=solve_path(s,base,types,gamma,[cap])[cap]
                rows.append(dict(total_records=n,entrant_pool=int((~base).sum()),incumbent_places=int(base.sum()),
                    types=K,exchange_cap=cap,actual_exchanges=p.m,seconds=time.perf_counter()-start,
                    predicted_net_total=float(p.weights(n)@s-p.cost),rep=rep))
            print(f'scale total_n={n} K={K} cap={cap} actual={p.m} seconds={rows[-1]["seconds"]:.3f}',flush=True)
    pd.DataFrame(rows).to_csv(dest/'runtime.csv',index=False)
