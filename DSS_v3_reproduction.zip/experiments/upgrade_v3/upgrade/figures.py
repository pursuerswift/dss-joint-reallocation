"""Diagnostic charts for the experiments."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator

COLORS={'score_only':'#9C9C9C','mean_cost':'#E69F00','additive_cost':'#56B4E9','cost_flow':'#0072B2','evidence_flow':'#D55E00','combined':'#009E73'}


def save(fig,dest,name):
    fig.savefig(dest/f'{name}.png',dpi=180,bbox_inches='tight')
    fig.savefig(dest/f'{name}.svg',bbox_inches='tight')
    plt.close(fig)


def run(root,dest):
    dest.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    sf=root/'simulate/summary.csv'
    if sf.exists():
        full=pd.read_csv(sf,keep_default_na=False)
        d=full[(full.rule=='max_t') & (full.n==full.n.max())]
        regimes=list(d.regime.unique());fig,axes=plt.subplots(2,3,figsize=(12,6.5),constrained_layout=True)
        methods=['score_only','mean_cost','additive_cost','cost_flow','evidence_flow']
        for ax,regime in zip(axes.ravel(),regimes):
            t=d[d.regime==regime].set_index('method').loc[methods]
            ax.barh(np.arange(len(t)),t.gain_per_1000,color=[COLORS[k] for k in methods])
            ax.errorbar(t.gain_per_1000,np.arange(len(t)),xerr=1.96*t.gain_mcse,fmt='none',color='black',capsize=2)
            ax.set_yticks(np.arange(len(t)),[k.replace('_',' ') for k in methods]);ax.invert_yaxis()
            ax.axvline(0,color='black',lw=.6);ax.set_title(regime.replace('_',' '));ax.set_xlabel('Adopted true net gain / 1,000')
        fig.suptitle('Known-truth mechanism experiments | error bars: Monte Carlo uncertainty')
        save(fig,dest,'simulation_net_value')
        fig,ax=plt.subplots(figsize=(9,4),constrained_layout=True)
        for j,method in enumerate(methods):
            t=d[d.method==method].set_index('regime').loc[regimes]
            ax.plot(regimes,t.adoption_rate,marker='o',label=method.replace('_',' '),color=COLORS[method])
        ax.set_ylim(-.03,1.03);ax.set_ylabel('Adoption probability');ax.set_xlabel('Predeclared regime')
        ax.tick_params(axis='x',rotation=20);ax.legend(ncol=3,frameon=False)
        save(fig,dest,'simulation_adoption')
        mechanisms=['diffuse','concentrated','variance_tradeoff','pair_cost']
        fig,axes=plt.subplots(2,2,figsize=(10,7),constrained_layout=True)
        for ax,regime in zip(axes.ravel(),mechanisms):
            for method in ['cost_flow','evidence_flow','combined']:
                t=full[(full.rule=='max_t') & (full.regime==regime) & (full.method==method)].sort_values('n')
                ax.errorbar(t.n,t.gain_per_1000,yerr=1.96*t.gain_mcse,marker='o',capsize=3,
                            label=method.replace('_',' '),color=COLORS[method])
            ax.set_xscale('log');ax.set_title(regime.replace('_',' '))
            sizes=sorted(full.n.unique());ax.set_xticks(sizes,[f'{int(n):,}' for n in sizes])
            ax.xaxis.set_minor_locator(NullLocator())
            ax.set_xlabel('Evaluation sample size');ax.set_ylabel('Adopted net gain / 1,000')
        axes[0,0].legend(frameon=False)
        fig.suptitle('Net value across evidence budgets | 95% Monte Carlo intervals')
        save(fig,dest,'simulation_sample_size')
        pf=root/'simulate/paired_contrasts.csv'
        if pf.exists():
            pairs=pd.read_csv(pf,keep_default_na=False)
            fig,axes=plt.subplots(2,2,figsize=(10,6.5),constrained_layout=True)
            for ax,regime in zip(axes.ravel(),mechanisms):
                t=pairs[(pairs.rule=='max_t') & (pairs.regime==regime) & (pairs.comparator=='cost_flow')].sort_values('n')
                ax.errorbar(t.n,t['mean'],yerr=1.96*t.mcse,marker='o',capsize=3,color=COLORS['evidence_flow'])
                ax.axhline(0,color='black',lw=.7);ax.set_xscale('log')
                sizes=sorted(pairs.n.unique());ax.set_xticks(sizes,[f'{int(n):,}' for n in sizes])
                ax.xaxis.set_minor_locator(NullLocator())
                ax.set_title(regime.replace('_',' '));ax.set_xlabel('Evaluation sample size')
                ax.set_ylabel('Evidence flow - cost flow / 1,000')
            fig.suptitle('Paired net-value differences | 95% Monte Carlo intervals')
            save(fig,dest,'simulation_paired_gain')
    ef=root/'empirical/test_candidates.csv'
    if ef.exists():
        d=pd.read_csv(ef)
        scenario='pair_low' if 'pair_low' in set(d.scenario) else str(d.scenario.iloc[0])
        d=d[(d.scenario==scenario) & (d.cap==1) & (d.seed==d.seed.min())]
        datasets=list(d.dataset.unique());fig,axes=plt.subplots(1,len(datasets),figsize=(12,4),constrained_layout=True,squeeze=False)
        methods=['score_only','mean_cost','additive_cost','cost_flow','evidence_flow']
        for ax,ds in zip(axes.ravel(),datasets):
            t=d[d.dataset==ds].groupby('method')[['net','se']].mean().reindex(methods)
            ax.errorbar(t.net*1000,np.arange(len(t)),xerr=1.96*t.se*1000,fmt='o',color='#0072B2',capsize=3)
            ax.set_yticks(np.arange(len(t)),[k.replace('_',' ') for k in methods]);ax.invert_yaxis()
            ax.axvline(0,color='black',lw=.6);ax.set_title(ds);ax.set_xlabel('Held-out net gain / 1,000')
        fig.suptitle(f'Held-out candidate values | {scenario} | first split')
        save(fig,dest,'empirical_candidate_values')
        d=pd.read_csv(ef)
        d=d[(d.scenario==scenario) & (d.cap==1)]
        seeds=sorted(d.seed.unique())
        fig,axes=plt.subplots(1,len(datasets),figsize=(12,4.5),constrained_layout=True,squeeze=False)
        for ax,ds in zip(axes.ravel(),datasets):
            for method,offset in [('cost_flow',-.1),('evidence_flow',.1)]:
                t=d[(d.dataset==ds)&(d.method==method)].set_index('seed').loc[seeds]
                y=np.arange(len(seeds))+offset
                ax.errorbar(t.net*1000,y,xerr=1.96*t.se*1000,fmt='o',capsize=3,
                            label=method.replace('_',' '),color=COLORS[method])
            ax.set_yticks(np.arange(len(seeds)),[str(seed) for seed in seeds]);ax.invert_yaxis()
            ax.axvline(0,color='black',lw=.6);ax.set_title(ds)
            ax.set_xlabel('Held-out candidate net gain / 1,000')
        handles,labels=axes[0,0].get_legend_handles_labels()
        fig.legend(handles,labels,frameon=False,ncol=2,loc='lower center',bbox_to_anchor=(.5,-.06))
        fig.suptitle(f'Candidate values across splits | {scenario} | full cap | pointwise 95% intervals')
        save(fig,dest,'empirical_split_values')
    rf=root/'scale/runtime.csv'
    if rf.exists():
        d=pd.read_csv(rf);fig,ax=plt.subplots(figsize=(6.5,4),constrained_layout=True)
        for K,g in d.groupby('types'):
            t=g.groupby('total_records').seconds.mean()
            ax.loglog(t.index,t,marker='o',label=f'{K} types')
        ax.set_xlabel('Total eligible records (both sides combined)');ax.set_ylabel('Seconds, including sorting')
        ax.legend(frameon=False);save(fig,dest,'flow_scaling')
    print('experiment figures saved',flush=True)
