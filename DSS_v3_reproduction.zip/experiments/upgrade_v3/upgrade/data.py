"""Original-source readers, reproducible partitions, train-only model fitting."""
from dataclasses import dataclass
import os
from pathlib import Path
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.metrics import log_loss
from .flow import topk
from .inference import aipw

ROOT=(Path(os.environ['CAUSAL_PROJECT_ROOT']) if 'CAUSAL_PROJECT_ROOT' in os.environ
      else next(p for p in Path(__file__).resolve().parents if (p/'papers/dss/r6/input').is_dir()))
SOURCE=ROOT/'papers/dss/r6'


@dataclass
class Cohort:
    ids: np.ndarray
    x: np.ndarray
    a: np.ndarray
    y: object
    source_rows: np.ndarray


def source_info(path):
    return dict(path=str(path.relative_to(ROOT)).replace('\\','/'),bytes=path.stat().st_size)


def load(dataset,seed,cfg):
    external=None
    if dataset=='hillstrom':
        path=SOURCE/'input/hillstrom.csv';manifest=[source_info(path)];f=pd.read_csv(path)
        a=f.segment.map({'No E-Mail':0,'Mens E-Mail':1,'Womens E-Mail':2}).to_numpy(int)
        x=np.column_stack([f.recency,np.log1p(f.history),f.mens,f.womens,f.newbie,
          f.zip_code.replace({'Surburban':'Suburban'}).map({'Rural':0,'Suburban':1,'Urban':2}),
          f.channel.map({'Multichannel':0,'Phone':1,'Web':2})]).astype(float)
        y=f.visit.to_numpy(float);ids=np.arange(1,len(f)+1);prop=[1/3]*3;cats=[5,6]
    elif dataset=='karlan_list':
        path=SOURCE/'input/AER_merged.dta';manifest=[source_info(path)];f=pd.read_stata(path,convert_categoricals=False)
        a=f.treatment.to_numpy(int);x=f[['hpa','ltmedmra','freq','years','mrm2','dormant']].to_numpy(float)
        y=f.gave.to_numpy(float);ids=np.arange(1,len(f)+1);prop=[1/3,2/3];cats=[]
    elif dataset=='promotion':
        path=SOURCE/'sources/udacity/training.csv';test=path.with_name('Test.csv')
        manifest=[source_info(path),source_info(test)];f=pd.read_csv(path)
        a=(f.Promotion=='Yes').to_numpy(int);x=f[[f'V{i}' for i in range(1,8)]].to_numpy(float)
        y=f.purchase.to_numpy(float);ids=f.ID.to_numpy();prop=[.5,.5];cats=[]
        t=pd.read_csv(test,usecols=['ID','Promotion']+[f'V{i}' for i in range(1,8)])
        external=Cohort(t.ID.to_numpy(),t[[f'V{i}' for i in range(1,8)]].to_numpy(float),
                         (t.Promotion=='Yes').to_numpy(int),None,np.arange(len(t)))
    else: raise ValueError(dataset)
    ix=np.arange(len(y))
    if external is None:
        tr,rest=train_test_split(ix,train_size=cfg['train_fraction'],stratify=a,random_state=seed)
        tu,rest=train_test_split(rest,train_size=cfg['tune_fraction']/(1-cfg['train_fraction']),stratify=a[rest],random_state=seed+1)
        ga,te=train_test_split(rest,train_size=cfg['gate_fraction']/(1-cfg['train_fraction']-cfg['tune_fraction']),stratify=a[rest],random_state=seed+2)
    else:
        tr,rest=train_test_split(ix,train_size=.6,stratify=a,random_state=seed)
        tu,ga=train_test_split(rest,train_size=.5,stratify=a[rest],random_state=seed+1);te=None
    parts={}
    for name,indices in [('train',tr),('tune',tu),('gate',ga),('test',te)]:
        if indices is None: parts[name]=external;continue
        j=np.sort(indices)
        parts[name]=Cohort(ids[j],x[j],a[j],None if name=='test' else y[j],j)
    for n1 in parts:
        for n2 in parts:
            if n1<n2 and np.intersect1d(parts[n1].ids,parts[n2].ids).size:
                raise ValueError('Partition ID overlap')
    if any(len(np.unique(c.ids))!=len(c.ids) for c in parts.values()): raise ValueError('Duplicate IDs')
    return parts,np.asarray(prop),cats,manifest


def reveal_test(dataset,cohort,freeze_file):
    if not freeze_file.exists(): raise RuntimeError('Save all gate choices before test evaluation')
    if dataset=='hillstrom': y=pd.read_csv(SOURCE/'input/hillstrom.csv',usecols=['visit']).visit.to_numpy(float)
    elif dataset=='karlan_list': y=pd.read_stata(SOURCE/'input/AER_merged.dta',columns=['gave'],convert_categoricals=False).gave.to_numpy(float)
    else:
        f=pd.read_csv(SOURCE/'sources/udacity/Test.csv',usecols=['ID','purchase'])
        if not np.array_equal(f.ID.to_numpy(),cohort.ids): raise ValueError('Test IDs out of order')
        y=f.purchase.to_numpy(float)
    labels=y[cohort.source_rows]
    if not np.isin(labels,[0,1]).all(): raise ValueError('Invalid outcome')
    return labels


def _model(x,y,targets,params,cfg,seed,cats,binary=True):
    if len(np.unique(y))<2:
        return [np.full(len(t),float(np.mean(y))) for t in targets]
    common=dict(**params,learning_rate=.05,min_child_samples=cfg['min_child_samples'],
        reg_lambda=5,max_bin=63,n_jobs=cfg['threads'],verbosity=-1,deterministic=True,
        force_col_wise=True,random_state=seed)
    model=lgb.LGBMClassifier(**common) if binary else lgb.LGBMRegressor(**common)
    model.fit(x,y,categorical_feature=cats)
    return [model.booster_.predict(t,num_threads=cfg['threads']) for t in targets]


def fitted_predictions(parts,prop,cats,cfg,seed,quota):
    train=parts['train'];names=['tune','gate','test'];arms=len(prop)
    pre=SimpleImputer(strategy='median')
    xt=pre.fit_transform(train.x)
    xx=[pre.transform(parts[name].x) for name in names]
    mus=[]
    for j,param in enumerate(cfg['models']):
        out=[np.empty((len(x),arms)) for x in xx]
        for arm in range(arms):
            keep=train.a==arm
            pred=_model(xt[keep],train.y[keep],xx,param,cfg,seed+j,cats)
            for dst,p in zip(out,pred): dst[:,arm]=np.clip(p,1e-6,1-1e-6)
        mus.append(out)
    oof=np.empty((len(train.ids),arms))
    for fold,(fit,hold) in enumerate(StratifiedKFold(2,shuffle=True,random_state=seed+71).split(xt,train.a)):
        for arm in range(arms):
            use=fit[train.a[fit]==arm]
            oof[hold,arm]=_model(xt[use],train.y[use],[xt[hold]],cfg['models'][0],cfg,seed+fold,cats)[0]
    target=aipw(train.a,train.y,np.clip(oof,1e-6,1-1e-6),prop)
    scores={}
    for j,param in enumerate(cfg['models']):
        scores[f'T{j}']=[m[:,1]-m[:,0] for m in mus[j]]
        scores[f'DR{j}']=[np.clip(p,-1,1) for p in _model(xt,target,xx,param,cfg,seed+100+j,cats,False)]
    tune=parts['tune'];phi=aipw(tune.a,tune.y,mus[0][0],prop)
    values={key:float(topk(s[0],tune.ids,quota)@phi/len(phi)) for key,s in scores.items()}
    family=max(values,key=lambda key:(values[key],-len(key),key))
    arm=tune.a==1
    losses=[log_loss(tune.y[arm],m[0][arm,1],labels=[0,1]) for m in mus]
    response_index=int(np.argmin(losses))
    output={name:dict(mu=mus[0][i],response=mus[response_index][i][:,1],score=scores[family][i])
            for i,name in enumerate(names)}
    metadata=dict(challenger=family,response_candidate=response_index,tune_policy_values=values,
                  response_tune_logloss=losses,nuisance_candidate=0,
                  dr_training='two-fold train-only cross-fitting',categorical_indices=cats)
    return output,metadata


def fit_types(dataset,x):
    cols=(0,6) if dataset=='hillstrom' else ((3,2) if dataset=='karlan_list' else (0,1))
    edges=[]
    for i,col in enumerate(cols):
        if dataset=='hillstrom' and i==1: edges.append([.5,1.5])
        else: edges.append(np.nanquantile(x[:,col],[1/3,2/3]).tolist())
    return dict(columns=list(cols),edges=edges,K=9)


def apply_types(x,definition):
    a=[np.searchsorted(edges,np.nan_to_num(x[:,col],nan=float(np.mean(edges))),side='left')
       for col,edges in zip(definition['columns'],definition['edges'])]
    return a[0]*3+a[1]
