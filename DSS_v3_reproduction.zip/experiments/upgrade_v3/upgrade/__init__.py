"""Transition-aware allocation experiments, version 3."""
