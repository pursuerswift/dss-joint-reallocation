"""Full-cost comparators: an independent sparse LP and greedy selection/rematching."""
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from .flow import Plan,retention,rematch


def generic_lp(score,base,types,gamma,cap):
    """Integral min-cost flow LP with record arcs, type arcs and an unused-cap arc.

    All costs remain floating point. The source supplies cap units; unused units
    pass directly to the sink. Network integrality supplies a discrete solution.
    """
    e,l=np.flatnonzero(~base),np.flatnonzero(base)
    ne,nl=len(e),len(l);K=len(gamma)
    cap=min(int(cap),ne,nl)
    if cap<=0:return retention()
    z0=ne+nl;nv=z0+K*K+1
    zi=np.arange(K*K)+z0
    # entrant balance: -x + outflow = 0; leaver balance: inflow - y = 0.
    rr=np.r_[types[e],np.full(ne,2*K),K+types[l],np.repeat(np.arange(K),K),K+np.tile(np.arange(K),K),2*K]
    cc=np.r_[np.arange(ne),np.arange(ne),ne+np.arange(nl),zi,zi,nv-1]
    vv=np.r_[-np.ones(ne),np.ones(ne),-np.ones(nl),np.ones(K*K),np.ones(K*K),1.]
    # With -x+z=0 and -y+z=0, reversing all leaver rows gives incidence signs.
    A=coo_matrix((vv,(rr,cc)),shape=(2*K+1,nv)).tocsc()
    b=np.r_[np.zeros(2*K),float(cap)]
    cost=np.r_[-score[e],score[l],gamma.ravel(),0.]
    bounds=np.column_stack([np.zeros(nv),np.r_[np.ones(ne+nl),np.full(K*K+1,cap)]])
    opt=linprog(cost,A_eq=A,b_eq=b,bounds=bounds,method='highs',
                options={'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8})
    if not opt.success:raise RuntimeError(opt.message)
    integer=np.rint(opt.x).astype(int)
    if np.max(np.abs(opt.x-integer))>1e-6:raise ArithmeticError('Fractional network LP solution')
    es=[e[(types[e]==a)&(integer[:ne]>0)] for a in range(K)]
    ls=[l[(types[l]==a)&(integer[ne:z0]>0)] for a in range(K)]
    allocation=integer[z0:-1].reshape(K,K)
    pe=np.zeros(K,int);pl=np.zeros(K,int);pairs=[]
    for a in range(K):
        for btype in range(K):
            for _ in range(allocation[a,btype]):
                pairs.append((es[a][pe[a]],ls[btype][pl[btype]]));pe[a]+=1;pl[btype]+=1
    return Plan(np.asarray(pairs,int).reshape(-1,2),float(np.sum(allocation*gamma)),
                key='generic_lp',method='generic_lp',objective=float(-opt.fun))


def greedy_rematch(score,base,types,gamma,cap):
    """Choose best available net-gain pair, then optimally rematch selected lists."""
    K=len(gamma);e=np.flatnonzero(~base);l=np.flatnonzero(base)
    es=[e[types[e]==a] for a in range(K)];ls=[l[types[l]==a] for a in range(K)]
    es=[a[np.lexsort((a,-score[a]))] for a in es]
    ls=[a[np.lexsort((a,score[a]))] for a in ls]
    pe=np.zeros(K,int);pl=np.zeros(K,int);picked_e=[];picked_l=[]
    for _ in range(min(int(cap),len(e),len(l))):
        ev=np.array([score[a[pe[t]]] if pe[t]<len(a) else -np.inf for t,a in enumerate(es)])
        lv=np.array([score[a[pl[t]]] if pl[t]<len(a) else np.inf for t,a in enumerate(ls)])
        margin=ev[:,None]-lv[None,:]-gamma
        a,b=np.unravel_index(np.argmax(margin),margin.shape)
        if margin[a,b]<=1e-11:break
        picked_e.append(es[a][pe[a]]);picked_l.append(ls[b][pl[b]])
        pe[a]+=1;pl[b]+=1
    p=rematch(picked_e,picked_l,types,gamma)
    p.key=p.method='greedy_rematch'
    return p
