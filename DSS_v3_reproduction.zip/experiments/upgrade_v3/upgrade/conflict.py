"""Mechanism-directed competition experiments; all cells and budgets are retained."""
from concurrent.futures import ProcessPoolExecutor, as_completed
import json
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from .flow import solve_path
from .comparators import generic_lp, greedy_rematch
from .inference import evaluate


def population(cfg, family, n, k, rep, strength, noise):
    rng = np.random.default_rng(np.random.SeedSequence([cfg['seed'], n, k, rep, int(family == 'random_asymmetric')]))
    q = int(n * cfg['quota'])
    base = np.arange(n) < q
    types = rng.integers(k, size=n)
    half = k // 2
    if family == 'specialist_flexible':
        # Flexible entrants can use every resource; specialists depend on one
        # resource category. Flexible entrants prefer scarce specialist resources.
        means = np.where(types < half, .20, .18)
        tau = np.where(base, 0., means) + .015 * np.tanh(rng.normal(size=n))
        target = .24 + .02 * rng.random((k, k))
        target[:half, :half] = .01 + .01 * rng.random((half, half))
        target[:half, half:] = .03 + .01 * rng.random((half, half))
        for a in range(half):
            target[half+a, a] = .015 + .01 * rng.random()
    else:
        tau = np.where(base, .02, .14) + .04 * np.tanh(rng.normal(size=n))
        target = .005 + .24 * rng.random((k, k))
    gamma = (1-strength)*.02 + strength*target
    score = tau + noise*rng.normal(size=n)
    return score, base, types, gamma, tau


def cell(task):
    cfg, family, n, k, strength, noise = task
    rows = []
    with threadpool_limits(limits=1):
        for rep in range(cfg['repetitions']):
            score, base, types, gamma, tau = population(cfg, family, n, k, rep, strength, noise)
            caps = [int(base.sum()*share) for share in cfg['cap_shares']]
            path = solve_path(score, base, types, gamma, caps)
            for share, cap in zip(cfg['cap_shares'], caps):
                plans = {'type_flow':path[cap],
                         'greedy_rematch':greedy_rematch(score,base,types,gamma,cap),
                         'generic_lp':generic_lp(score,base,types,gamma,cap)}
                for method, plan in plans.items():
                    v=evaluate(plan,tau); s=evaluate(plan,score)
                    rows.append(dict(family=family,n=n,types=k,strength=strength,noise=noise,
                        rep=rep,cap_share=share,cap=cap,method=method,exchanges=plan.m,
                        true_net_per_1000=1000*v['net'],predicted_net_per_1000=1000*s['net'],
                        gross_per_1000=1000*v['gross'],cost_per_1000=1000*v['cost'],
                        reverse_augmentations=plan.reverse_augmentations if method=='type_flow' else np.nan,
                        reverse_arc_traversals=plan.reverse_arc_traversals if method=='type_flow' else np.nan))
    return rows


def run(cfg,dest,resume=False,workers=4):
    cells=dest/'cells';cells.mkdir(exist_ok=True)
    tasks=[]
    for family in cfg['families']:
        for n in cfg['sizes']:
            for k in cfg['types']:
                for strength in cfg['strengths']:
                    for noise in cfg['score_noise']:
                        name=f'{family}_{n}_{k}_{strength:g}_{noise:g}.csv'
                        if not (resume and (cells/name).exists()):
                            tasks.append((cfg,family,n,k,strength,noise))
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for future in as_completed([pool.submit(cell,t) for t in tasks]):
            rows=future.result();a=rows[0]
            name=f"{a['family']}_{a['n']}_{a['types']}_{a['strength']:g}_{a['noise']:g}.csv"
            pd.DataFrame(rows).to_csv(cells/name,index=False)
            print('conflict '+name,flush=True)
    data=pd.concat([pd.read_csv(p) for p in sorted(cells.glob('*.csv'))],ignore_index=True)
    data.to_csv(dest/'replicates.csv',index=False)
    keys=['family','n','types','strength','noise','cap_share']
    summary=data.groupby(keys+['method']).agg(mean_net=('true_net_per_1000','mean'),
        sd_net=('true_net_per_1000','std'),mean_objective=('predicted_net_per_1000','mean'),
        mean_exchanges=('exchanges','mean'),mean_reverse=('reverse_augmentations','mean'),
        mean_reverse_arcs=('reverse_arc_traversals','mean'),repetitions=('rep','size')).reset_index()
    summary['mcse']=summary.sd_net/np.sqrt(summary.repetitions)
    summary.to_csv(dest/'summary.csv',index=False)
    index=keys+['rep']
    wide=data.pivot(index=index,columns='method',values=['true_net_per_1000','predicted_net_per_1000'])
    differences=pd.DataFrame(index=wide.index)
    differences['true_difference']=wide['true_net_per_1000']['type_flow']-wide['true_net_per_1000']['greedy_rematch']
    differences['objective_difference']=wide['predicted_net_per_1000']['type_flow']-wide['predicted_net_per_1000']['greedy_rematch']
    differences['lp_gap']=wide['predicted_net_per_1000']['type_flow']-wide['predicted_net_per_1000']['generic_lp']
    differences=differences.reset_index();differences.to_csv(dest/'paired_replicates.csv',index=False)
    contrasts=differences.groupby(keys).agg(mean_difference=('true_difference','mean'),sd=('true_difference','std'),
        repetitions=('rep','size'),mean_objective_difference=('objective_difference','mean'),
        min_objective_difference=('objective_difference','min'),max_objective_difference=('objective_difference','max')).reset_index()
    contrasts['mcse']=contrasts.sd/np.sqrt(contrasts.repetitions)
    contrasts.to_csv(dest/'paired_contrasts.csv',index=False)
    lp_gap=float(differences.lp_gap.abs().max())
    identity=float((data.true_net_per_1000-data.gross_per_1000+data.cost_per_1000).abs().max())
    assert lp_gap < 1e-6
    assert identity < 1e-8
    assert differences.objective_difference.min() > -1e-6
    assert (data.exchanges<=data.cap).all()
    (dest/'validation.json').write_text(json.dumps(dict(status='passed',method_rows=len(data),
        paired_budget_records=len(differences),lp_max_gap=lp_gap,net_identity_residual=identity),indent=2),encoding='utf-8')
