"""Mechanism experiments with known conditional treatment effects."""
import time
import numpy as np
import pandas as pd
from scipy.special import expit
from .flow import topk, solve_path
from .inference import aipw, support_width, design_variance, certify, choose, evaluate
from .policies import make_menu, cost_scenario, METHODS


def instance(regime, n, seed, noise, quota):
    rng=np.random.default_rng(seed)
    x=rng.normal(size=(n,4)); ids=np.arange(n)
    response=x[:,0]+.25*x[:,2]
    mu0=.05+.18*expit(x[:,0])
    if regime=='equal_value': tau=np.zeros(n)
    elif regime=='harm': tau=.03+.15*expit(response)
    elif regime=='diffuse': tau=.025+.06*np.tanh(x[:,1])
    elif regime=='concentrated': tau=.005+.22*(x[:,1]>1.2)
    elif regime=='variance_tradeoff':
        high=x[:,2]>0
        mu0=np.where(high,.35,.015)
        tau=.14*expit(1.5*x[:,1])*(1+.15*high)
    elif regime=='pair_cost': tau=.04+.16*expit(x[:,1])
    else: raise ValueError(regime)
    mu=np.column_stack([mu0,mu0+tau])
    if not ((mu>=0).all() and (mu<=1).all()): raise ValueError('Invalid DGP')
    score=(-tau if regime=='harm' else tau)+noise*rng.normal(size=n)
    base=topk(response,ids,quota)
    types=np.digitize(x[:,3],[-.43,.43])
    gamma=cost_scenario(3,0 if regime=='equal_value' else .005,0 if regime=='equal_value' else (.08 if regime=='pair_cost' else .01))
    a=rng.binomial(1,.5,n);y=rng.binomial(1,mu[ids,a])
    return dict(score=score,base=base,types=types,gamma=gamma,mu=mu,tau=tau,a=a,y=y)


def _batch(task):
    from threadpoolctl import threadpool_limits
    with threadpool_limits(limits=1):
        return _batch_inner(task)


def _batch_inner(task):
    cfg,ri,regime,n,first,last=task
    scfg=cfg['simulations']
    rows=[]
    for rep in range(first,last):
        seed=np.random.SeedSequence([cfg['seed'],ri,n,rep])
        d=instance(regime,n,seed,scfg['score_noise'],cfg['quota'])
        variance=design_variance(d['mu'],[.5,.5])
        plans=make_menu(d['score'],d['base'],d['types'],d['gamma'],variance,
                        cfg['caps'],cfg['eta_factors'],cfg['design_z'])
        phi=aipw(d['a'],d['y'],d['mu'],[.5,.5])
        ev=certify(plans,phi,support_width(d['mu'],[.5,.5]),cfg['alpha'],
                    cfg['gaussian_draws'],cfg['seed']+rep)
        bykey={p.key:p for p in plans}
        truth={p.key:evaluate(p,d['tau'])['net'] for p in plans}
        oracle=solve_path(d['tau'],d['base'],d['types'],d['gamma'],[int(d['base'].sum())])
        oracle_gain=evaluate(next(iter(oracle.values())),d['tau'])['net']
        for rule in ['max_t','bonferroni','hoeffding']:
            any_violation=any(r[f'lcb_{rule}']>truth[r['key']]+1e-10 for r in ev)
            for method in METHODS+['combined']:
                decision=choose(ev,rule,None if method=='combined' else method)
                key=decision['key'];p=bykey[key];value=truth[key]
                rows.append(dict(regime=regime,n=n,rep=rep,method=method,rule=rule,
                    selected=key,adopted=int(p.m>0),harm=int(p.m>0 and value < -1e-10),
                    true_net=value,true_net_per_1000=1000*value,exchanges=p.m,
                    turnover=p.m/n,oracle_net=oracle_gain,regret=oracle_gain-value,
                    any_lcb_violation=int(any_violation),unique_menu=decision['unique_menu'],
                    estimated_net=decision['net'],lcb=decision[f'lcb_{rule}']))
    return regime,n,rows


def run(cfg,dest,resume=False,workers=1):
    from concurrent.futures import ProcessPoolExecutor, as_completed
    dest.mkdir(parents=True,exist_ok=True)
    cells=dest/'cells';cells.mkdir(exist_ok=True)
    allrows=[];start=time.perf_counter();pending={};tasks=[]
    scfg=cfg['simulations'];reps=scfg['repetitions']
    for ri,regime in enumerate(scfg['regimes']):
        for n in scfg['sizes']:
            cell=cells/f'{regime}_{n}.csv'
            if resume and cell.exists():
                allrows.extend(pd.read_csv(cell,keep_default_na=False).to_dict('records'));continue
            pending[regime,n]=[]
            for first in range(0,reps,50):
                tasks.append((cfg,ri,regime,n,first,min(first+50,reps)))
    def collect(result):
        regime,n,rows=result
        records=pending[regime,n];records.extend(rows)
        completed=len(records)//18
        print(f'simulation {regime} n={n} progress={completed}/{reps} elapsed={time.perf_counter()-start:.1f}s',flush=True)
        if completed==reps:
            records.sort(key=lambda r:(r['rep'],r['rule'],r['method']))
            pd.DataFrame(records).to_csv(cells/f'{regime}_{n}.csv',index=False)
            allrows.extend(records)
            del pending[regime,n]
    if workers==1:
        for task in tasks: collect(_batch(task))
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            for future in as_completed([pool.submit(_batch,task) for task in tasks]):
                collect(future.result())
    frame=pd.DataFrame(allrows);frame.to_csv(dest/'replicates.csv',index=False)
    summary=frame.groupby(['regime','n','method','rule']).agg(
        repetitions=('rep','size'),adoption_rate=('adopted','mean'),harm_rate=('harm','mean'),
        gain_per_1000=('true_net_per_1000','mean'),gain_sd=('true_net_per_1000','std'),
        mean_turnover=('turnover','mean'),mean_regret=('regret','mean'),
        simultaneous_violation_rate=('any_lcb_violation','mean')).reset_index()
    summary['gain_mcse']=summary.gain_sd/np.sqrt(summary.repetitions)
    summary['adoption_mcse']=np.sqrt(summary.adoption_rate*(1-summary.adoption_rate)/summary.repetitions)
    summary.to_csv(dest/'summary.csv',index=False)
    # Paired contrasts, including zeros when either method retains.
    piv=frame.pivot(index=['regime','n','rep','rule'],columns='method',values='true_net_per_1000')
    comparisons=[]
    for other in ['score_only','mean_cost','additive_cost','cost_flow']:
        delta=(piv.evidence_flow-piv[other]).rename('difference').reset_index()
        tab=delta.groupby(['regime','n','rule']).difference.agg(['mean','std','size']).reset_index()
        tab['comparator']=other;tab['mcse']=tab['std']/np.sqrt(tab['size'])
        comparisons.append(tab)
    pd.concat(comparisons).to_csv(dest/'paired_contrasts.csv',index=False)
    return summary
