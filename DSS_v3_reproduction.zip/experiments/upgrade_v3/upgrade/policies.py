"""Cost and evidence-aware exchange candidates with equal cap-menu sizes."""
import numpy as np
from dataclasses import replace
from .flow import retention, solve_path, rematch

METHODS = ['score_only','mean_cost','additive_cost','cost_flow','evidence_flow']


def make_menu(score, base, types, gamma, variance, cap_fractions, eta_factors, design_z=2.5):
    score, base, types, gamma = np.asarray(score), np.asarray(base, bool), np.asarray(types), np.asarray(gamma)
    k, n = int(base.sum()), len(base)
    cap_pairs = [(float(f), min(int(k*f), n-k)) for f in cap_fractions]
    caps = [c for _, c in cap_pairs]
    plans = [retention()]
    ei, lj = np.flatnonzero(~base), np.flatnonzero(base)
    ei, lj = ei[np.lexsort((ei,-score[ei]))], lj[np.lexsort((lj,score[lj]))]
    gaps = score[ei[:min(len(ei),len(lj))]]-score[lj[:min(len(ei),len(lj))]]
    for name, threshold in [('score_only',0.0),('mean_cost',float(gamma.mean()))]:
        for fraction, cap in cap_pairs:
            m = min(cap, int((gaps > threshold).sum()))
            p = rematch(ei[:m], lj[:m], types, gamma)
            p.key, p.method, p.cap = f'{name}:cap{fraction:g}', name, fraction
            plans.append(p)
    additive = np.maximum(gamma.mean(1)[:,None]+gamma.mean(0)[None,:]-gamma.mean(),0)
    for name, costs in [('additive_cost',additive),('cost_flow',gamma)]:
        path = solve_path(score, base, types, costs, caps)
        for fraction, cap in cap_pairs:
            p = replace(path[cap])
            if name == 'additive_cost' and p.m:
                p = rematch(p.pairs[:,0],p.pairs[:,1],types,gamma)
            p.key, p.method, p.cap = f'{name}:cap{fraction:g}', name, fraction
            plans.append(p)
    # sqrt(V) variational representation yields a grid of ordinary flow solves.
    # Include eta=0; choose on the design surrogate, never gate outcomes.
    vref = max(2*max(caps)*float(np.median(variance)),1e-12)
    etas = [0.] + [design_z*f/(2*np.sqrt(vref)) for f in eta_factors]
    paths = [solve_path(score,base,types,gamma,caps,variance,eta) for eta in etas]
    for fraction, cap in cap_pairs:
        candidates = [path[cap] for path in paths] + [retention()]
        def merit(p):
            w = p.weights(n)
            return float(w@score-p.cost-design_z*np.sqrt((w*w)@variance))
        p = replace(max(candidates,key=lambda p:(merit(p),-p.m)))
        p.key, p.method, p.cap = f'evidence_flow:cap{fraction:g}', 'evidence_flow', fraction
        p.objective = merit(p)
        plans.append(p)
    # Each method contributes exactly one pre-outcome design per cap.
    return plans


def cost_scenario(K, base_cost, coupling, seed=20261116):
    # Nonseparable, type-specific transfer/onboarding matrix; fixed across splits.
    rng = np.random.default_rng(seed)
    pair = rng.uniform(.2,1.0,(K,K))
    np.fill_diagonal(pair,0)
    return base_cost + coupling*pair
