"""Focused structural experiments and independent solver comparison for the draft."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import json
from pathlib import Path
import time
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from upgrade.flow import topk,solve_path,rematch
from upgrade.comparators import generic_lp,greedy_rematch
from upgrade.inference import evaluate
from upgrade.policies import cost_scenario

HERE=Path(__file__).resolve().parent


def population(cfg,balance,noise,rep):
    n=cfg['n'];rng=np.random.default_rng(np.random.SeedSequence([cfg['seed'],int(balance=='skewed'),rep]))
    prob=np.ones(6)/6 if balance=='balanced' else np.array([.10,.15,.25,.25,.15,.10])
    types=rng.choice(6,n,p=prob)
    priority=rng.normal(size=n);priority[types>=3]=-np.inf
    base=topk(priority,np.arange(n),cfg['quota'])
    tau=np.array([.02,.04,.03,.16,.10,.07])[types]+.015*np.tanh(rng.normal(size=n))
    score=tau+noise*rng.normal(size=n)
    return score,base,types,tau


def matrix(cfg,family,strength):
    if family=='compatibility':h=1-np.eye(3)
    elif family=='asymmetric':h=np.array([[0.,.45,1.],[.9,0.,.55],[.35,.85,0.]])
    else:
        locations=np.array([0.,.35,1.]);h=np.abs(locations[:,None]-locations[None,:])
    groups=np.arange(6)%3
    return cfg['base_cost']+cfg['interaction_cost']*strength*h[groups[:,None],groups[None,:]]


def plans(score,base,types,gamma):
    cap=int(base.sum());e=np.flatnonzero(~base);l=np.flatnonzero(base)
    e=e[np.lexsort((e,-score[e]))];l=l[np.lexsort((l,score[l]))]
    gaps=score[e[:len(l)]]-score[l]
    out={}
    for method,threshold in [('score_rematch',0.),('mean_rematch',float(gamma.mean()))]:
        m=min(cap,int((gaps>threshold).sum()))
        out[method]=rematch(e[:m],l[:m],types,gamma)
    additive=np.maximum(gamma.mean(1)[:,None]+gamma.mean(0)[None,:]-gamma.mean(),0)
    p=solve_path(score,base,types,additive,[cap])[cap]
    out['additive_rematch']=rematch(p.pairs[:,0],p.pairs[:,1],types,gamma)
    out['greedy_rematch']=greedy_rematch(score,base,types,gamma,cap)
    out['type_flow']=solve_path(score,base,types,gamma,[cap])[cap]
    out['generic_lp']=generic_lp(score,base,types,gamma,cap)
    return out


def mechanism_cell(task):
    cfg,family,balance,strength,noise=task
    with threadpool_limits(limits=1):
        rows=[]
        for rep in range(cfg['repetitions']):
            score,base,types,tau=population(cfg,balance,noise,rep)
            gamma=matrix(cfg,family,strength)
            candidates=plans(score,base,types,gamma)
            opt=evaluate(candidates['generic_lp'],score)['net']
            for method,p in candidates.items():
                value=evaluate(p,tau);prediction=evaluate(p,score)
                rows.append(dict(family=family,balance=balance,strength=strength,noise=noise,rep=rep,
                    n=len(score),method=method,true_net_per_1000=1000*value['net'],
                    gross_per_1000=1000*value['gross'],cost_per_1000=1000*value['cost'],
                    predicted_net_per_1000=1000*prediction['net'],
                    objective_gap_per_1000=1000*(opt-prediction['net']),exchanges=p.m))
    return rows


def mechanisms(cfg,dest,workers,resume):
    folder=dest/'mechanisms';folder.mkdir(exist_ok=True);cells=folder/'cells';cells.mkdir(exist_ok=True)
    tasks=[]
    for f in cfg['families']:
        for b in cfg['balances']:
            for c in cfg['strengths']:
                for v in cfg['score_noise']:
                    name=f'{f}_{b}_{c:g}_{v:g}.csv'
                    if not (resume and (cells/name).exists()):tasks.append((cfg,f,b,c,v))
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for fut in as_completed([pool.submit(mechanism_cell,t) for t in tasks]):
            rows=fut.result();a=rows[0]
            name=f'{a["family"]}_{a["balance"]}_{a["strength"]:g}_{a["noise"]:g}.csv'
            pd.DataFrame(rows).to_csv(cells/name,index=False)
            print('mechanism '+name,flush=True)
    d=pd.concat([pd.read_csv(p) for p in sorted(cells.glob('*.csv'))],ignore_index=True)
    d.to_csv(folder/'replicates.csv',index=False)
    keys=['family','balance','strength','noise']
    s=d.groupby(keys+['method']).agg(mean_net=('true_net_per_1000','mean'),sd=('true_net_per_1000','std'),
        repetitions=('rep','size'),mean_exchanges=('exchanges','mean'),
        mean_objective_gap=('objective_gap_per_1000','mean')).reset_index()
    s['mcse']=s.sd/np.sqrt(s.repetitions);s.to_csv(folder/'summary.csv',index=False)
    wide=d.pivot(index=keys+['rep'],columns='method',values='true_net_per_1000')
    comparisons=[]
    for other in ['score_rematch','mean_rematch','additive_rematch','greedy_rematch','generic_lp']:
        delta=(wide.type_flow-wide[other]).rename('difference').reset_index()
        t=delta.groupby(keys).difference.agg(['mean','std','size']).reset_index()
        t['comparator']=other;t['mcse']=t['std']/np.sqrt(t['size']);comparisons.append(t)
    pd.concat(comparisons,ignore_index=True).to_csv(folder/'paired_contrasts.csv',index=False)


def benchmark(cfg,dest):
    folder=dest/'benchmark';folder.mkdir(exist_ok=True);rows=[]
    bc=cfg['benchmark']
    with threadpool_limits(limits=1):
        for n in bc['sizes']:
            for K in bc['types']:
                rng=np.random.default_rng(np.random.SeedSequence([cfg['seed'],n,K]))
                score=rng.normal(0,.1,n);base=topk(rng.normal(size=n),np.arange(n),cfg['quota'])
                types=rng.integers(0,K,n);gamma=cost_scenario(K,.005,.02,cfg['seed']);cap=int(base.sum()*.5)
                for rep in range(bc['repetitions']):
                    methods=['type_flow','generic_lp'] if rep%2==0 else ['generic_lp','type_flow']
                    for method in methods:
                        start=time.perf_counter()
                        p=solve_path(score,base,types,gamma,[cap])[cap] if method=='type_flow' else generic_lp(score,base,types,gamma,cap)
                        seconds=time.perf_counter()-start
                        rows.append(dict(n=n,types=K,cap=cap,rep=rep,method=method,seconds=seconds,
                                         objective=float(p.weights(n)@score-p.cost),exchanges=p.m))
                print(f'benchmark n={n} K={K} complete',flush=True)
                pd.DataFrame(rows).to_csv(folder/'runtime.csv',index=False)


def main():
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['mechanisms','benchmark','all'])
    p.add_argument('--run-id',default='joint_v3_20261117');p.add_argument('--workers',type=int,default=4)
    p.add_argument('--resume',action='store_true');p.add_argument('--smoke',action='store_true')
    args=p.parse_args();cfg=json.loads((HERE/'config/joint_followup.json').read_text())
    if args.smoke:
        cfg.update(n=300,repetitions=2);cfg['benchmark'].update(sizes=[300],types=[3],repetitions=1)
    dest=HERE/'results'/args.run_id;dest.mkdir(parents=True,exist_ok=True)
    (dest/'config.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
    if args.stage in ['mechanisms','all']:mechanisms(cfg,dest,args.workers,args.resume)
    if args.stage in ['benchmark','all']:benchmark(cfg,dest)
    (dest/f'{args.stage}_complete.json').write_text(json.dumps({'status':'complete'}),encoding='utf-8')


if __name__=='__main__':main()
