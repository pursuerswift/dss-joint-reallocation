"""Controlled allocation experiment: compatibility cost versus selection value.

Two incumbent groups share capacity. Two challenger groups have different
treatment gains and different compatibility with released capacity. The cost
matrix has constant row/column means, isolating its nonseparable component.
All selected lists, including score baselines, receive optimal rematching.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import json
from pathlib import Path
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from upgrade.flow import topk,solve_path
from upgrade.policies import make_menu
from upgrade.inference import design_variance,evaluate

HERE=Path(__file__).resolve().parent
DESIGN=dict(seed=20261117,sizes=[1500,6000],couplings=[0.,.25,.5,1.],
            repetitions=100,quota=.2,score_noise=.04,base_cost=.005,incompatibility_cost=.18,
            design_z=2.5,eta_factors=[.25,1.,4.],caps=[1.],
            role='controlled mechanism experiment; conditional true net value before adoption gating')


def cell(task):
    with threadpool_limits(limits=1): return inner(task)


def inner(task):
    n,coupling,cfg=task;rows=[]
    for rep in range(cfg['repetitions']):
        # Shared populations across cost strengths give paired cost responses.
        rng=np.random.default_rng(np.random.SeedSequence([cfg['seed'],n,rep]))
        types=rng.integers(0,4,n);ids=np.arange(n)
        incumbent_priority=rng.normal(size=n)
        incumbent_priority[types>=2]=-np.inf
        base=topk(incumbent_priority,ids,cfg['quota'])
        tau=np.array([.02,.04,.16,.10])[types]+.015*np.tanh(rng.normal(size=n))
        score=tau+cfg['score_noise']*rng.normal(size=n)
        mu=np.column_stack([np.full(n,.1),.1+tau])
        parity=np.arange(4)%2
        gamma=cfg['base_cost']+coupling*cfg['incompatibility_cost']*(parity[:,None]!=parity[None,:])
        plans=make_menu(score,base,types,gamma,design_variance(mu,[.5,.5]),
                        cfg['caps'],cfg['eta_factors'],cfg['design_z'])
        oracle=solve_path(tau,base,types,gamma,[int(base.sum())])[int(base.sum())]
        oracle_net=evaluate(oracle,tau)['net']
        for p in plans:
            if p.method=='retain': continue
            truth=evaluate(p,tau);prediction=evaluate(p,score)
            mismatches=int((types[p.pairs[:,0]]%2!=types[p.pairs[:,1]]%2).sum()) if p.m else 0
            rows.append(dict(n=n,coupling=coupling,rep=rep,method=p.method,
                true_net_per_1000=1000*truth['net'],gross_per_1000=1000*truth['gross'],
                cost_per_1000=1000*truth['cost'],predicted_net_per_1000=1000*prediction['net'],
                oracle_net_per_1000=1000*oracle_net,regret_per_1000=1000*(oracle_net-truth['net']),
                exchanges=p.m,incompatible_pairs=mismatches,turnover=p.m/n))
    return rows


def run(dest,workers):
    dest.mkdir(parents=True,exist_ok=True)
    (dest/'design.json').write_text(json.dumps(DESIGN,indent=2),encoding='utf-8')
    tasks=[(n,c,DESIGN) for n in DESIGN['sizes'] for c in DESIGN['couplings']]
    rows=[]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for future in as_completed([pool.submit(cell,t) for t in tasks]):
            result=future.result();rows.extend(result)
            print(f'coupling n={result[0]["n"]} strength={result[0]["coupling"]} complete',flush=True)
    d=pd.DataFrame(rows).sort_values(['n','coupling','rep','method'])
    d.to_csv(dest/'replicates.csv',index=False)
    s=d.groupby(['n','coupling','method']).agg(mean=('true_net_per_1000','mean'),
        sd=('true_net_per_1000','std'),repetitions=('rep','size'),mean_exchanges=('exchanges','mean'),
        mean_incompatible=('incompatible_pairs','mean'),mean_regret=('regret_per_1000','mean')).reset_index()
    s['mcse']=s.sd/np.sqrt(s.repetitions);s.to_csv(dest/'summary.csv',index=False)
    p=d.pivot(index=['n','coupling','rep'],columns='method',values='true_net_per_1000')
    comparisons=[]
    for method in ['score_only','mean_cost','additive_cost','evidence_flow']:
        delta=(p.cost_flow-p[method]).rename('difference').reset_index()
        t=delta.groupby(['n','coupling']).difference.agg(['mean','std','size']).reset_index()
        t['comparator']=method;t['mcse']=t['std']/np.sqrt(t['size']);comparisons.append(t)
    pd.concat(comparisons,ignore_index=True).to_csv(dest/'paired_contrasts.csv',index=False)
    plot(s,dest)


def plot(summary,dest):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from upgrade.figures import COLORS
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,len(DESIGN['sizes']),figsize=(11,4),constrained_layout=True)
    for ax,n in zip(axes,DESIGN['sizes']):
        for method,g in summary[summary.n==n].groupby('method'):
            if method=='additive_cost': continue  # Identical to mean_cost for this matrix.
            g=g.sort_values('coupling')
            ax.errorbar(g.coupling,g['mean'],yerr=1.96*g.mcse,marker='o',capsize=3,
                        color=COLORS[method],label='mean / additive cost' if method=='mean_cost' else method.replace('_',' '))
        ax.axhline(0,color='black',lw=.6);ax.set_title(f'n = {n:,}')
        ax.set_xlabel('Incompatibility cost strength');ax.set_ylabel('Conditional true net gain / 1,000')
    axes[0].legend(frameon=False,fontsize=8,loc='lower left',bbox_to_anchor=(0,.08))
    fig.suptitle('Joint selection and matching | fixed capacity | 95% Monte Carlo intervals')
    for ext in ['png','svg']:fig.savefig(dest/f'coupling_value.{ext}',dpi=180)
    plt.close(fig)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--run-id',default='expanded_v3')
    parser.add_argument('--workers',type=int,default=2);args=parser.parse_args()
    run(HERE/'results'/args.run_id/'coupling',args.workers)
