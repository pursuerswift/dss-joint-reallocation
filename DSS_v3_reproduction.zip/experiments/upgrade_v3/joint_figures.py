"""Figures for the joint-selection argument, with all structural conditions shown."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator

HERE=Path(__file__).resolve().parent
COLORS={'score_rematch':'#777777','mean_rematch':'#E69F00','additive_rematch':'#56B4E9',
        'greedy_rematch':'#222222','type_flow':'#0072B2','generic_lp':'#D55E00'}
LABELS={'score_rematch':'Score + rematching','mean_rematch':'Mean cost + rematching',
        'additive_rematch':'Additive cost + rematching','greedy_rematch':'Greedy + rematching',
        'type_flow':'Type flow','generic_lp':'Generic network LP'}


def save(fig,dest,name):
    for ext in ['png','svg']:fig.savefig(dest/f'{name}.{ext}',dpi=200,bbox_inches='tight')
    plt.close(fig)


def run(root):
    dest=root/'figures';dest.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    d=pd.read_csv(root/'mechanisms/summary.csv');d=d[d.noise==.04]
    families=['compatibility','asymmetric','distance'];balances=['balanced','skewed']
    fig,axes=plt.subplots(2,3,figsize=(12,7),constrained_layout=True)
    for i,balance in enumerate(balances):
        for j,family in enumerate(families):
            ax=axes[i,j]
            for method in ['score_rematch','mean_rematch','additive_rematch','type_flow','greedy_rematch']:
                t=d[(d.balance==balance)&(d.family==family)&(d.method==method)].sort_values('strength')
                if method=='greedy_rematch':
                    ax.plot(t.strength,t.mean_net,marker='^',mfc='none',ms=8,lw=0,color=COLORS[method],label=LABELS[method])
                else:
                    ax.errorbar(t.strength,t.mean_net,yerr=1.96*t.mcse,marker='o',capsize=2,
                                color=COLORS[method],label=LABELS[method])
            ax.axhline(0,color='black',lw=.5);ax.set_title(f'{family} | {balance}')
            ax.set_xticks([0,.5,1]);ax.set_xlabel('Transition-cost strength')
            if j==0:ax.set_ylabel('Conditional true net gain / 1,000')
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,-.06),ncol=3,frameon=False)
    fig.suptitle('Full-cost selection across transfer structures | score noise = 0.04 | 95% MC intervals')
    save(fig,dest,'structural_value')
    r=pd.read_csv(root/'benchmark/runtime.csv');fig,axes=plt.subplots(1,3,figsize=(12,3.8),constrained_layout=True)
    for ax,K in zip(axes,sorted(r.types.unique())):
        for method in ['type_flow','generic_lp']:
            t=r[(r.types==K)&(r.method==method)].groupby('n').seconds.agg(['mean','min','max'])
            ax.errorbar(t.index,t['mean'],yerr=np.array([t['mean']-t['min'],t['max']-t['mean']]),
                        marker='o',capsize=3,color=COLORS[method],label=LABELS[method])
        ax.set_xscale('log');ax.set_yscale('log');ax.set_title(f'{K} types')
        ax.set_xticks([1000,10000,100000],['1,000','10,000','100,000']);ax.xaxis.set_minor_locator(NullLocator())
        ax.set_xlabel('Total records');ax.set_ylabel('Seconds, including construction')
    axes[0].legend(frameon=False)
    fig.suptitle('Exact-solver computation | mean and range over three sequential repetitions')
    save(fig,dest,'exact_solver_scaling')
    old=pd.read_csv(HERE/'results/expanded_v3/coupling/replicates.csv')
    old=old[(old.n==6000)&(old.coupling==1)]
    methods=['score_only','mean_cost','cost_flow'];t=old.groupby('method')[['gross_per_1000','cost_per_1000','true_net_per_1000']].mean().loc[methods]
    fig,ax=plt.subplots(figsize=(8,4.2),constrained_layout=True)
    for offset,column,color,label in [(-.24,'gross_per_1000','#999999','Gross gain'),(0,'cost_per_1000','#E69F00','Transition cost'),(.24,'true_net_per_1000','#0072B2','Net gain')]:
        bars=ax.bar(np.arange(3)+offset,t[column],width=.23,color=color,label=label)
        ax.bar_label(bars,fmt='%.2f',fontsize=8,padding=3)
    ax.set_xticks(range(3),['Score + rematching','Mean cost + rematching','Joint type flow'])
    ax.set_ylabel('Success-equivalent units / 1,000');ax.legend(frameon=False,ncol=3,loc='upper center')
    ax.set_ylim(0,29);ax.set_title('Selection changes the cost of delivering benefit | n = 6,000, strong coupling')
    save(fig,dest,'value_decomposition')
    fig,axes=plt.subplots(1,3,figsize=(11,3.4),constrained_layout=True)
    ax=axes[0];cost=np.array([[.01,.02],[.02,.18]])
    ax.imshow(cost,cmap='Blues',vmin=0,vmax=.2)
    for i in range(2):
        for j in range(2):ax.text(j,i,f'{cost[i,j]:.2f}',ha='center',va='center',color='white' if cost[i,j]>.1 else 'black')
    ax.set_xticks([0,1],['Leaver 1','Leaver 2']);ax.set_yticks([0,1],['Entrant 1','Entrant 2']);ax.set_title('Transition cost')
    for ax,edges,title in [(axes[1],[(0,0)],'Greedy selection: net 0.19'),(axes[2],[(0,1),(1,0)],'Joint exchange: net 0.34')]:
        ax.set_xlim(-.5,1.5);ax.set_ylim(-.5,1.5);ax.axis('off');ax.set_title(title)
        for i,score in enumerate([.20,.18]):
            ax.scatter(0,1-i,s=500,color='#0072B2');ax.text(-.1,1-i,f'{score:.2f}',ha='right',va='center')
            ax.scatter(1,1-i,s=500,color='#999999');ax.text(1.1,1-i,'0.00',ha='left',va='center')
        for i,j in edges:ax.annotate('',xy=(.94,1-j),xytext=(.06,1-i),arrowprops={'arrowstyle':'->','lw':2,'color':'#0072B2'})
        ax.text(0,-.3,'Entrants',ha='center');ax.text(1,-.3,'Leavers',ha='center')
    save(fig,dest,'residual_exchange_example')
    print('Four argument figures saved.')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-id',default='joint_v3_20261117');a=p.parse_args()
    run(HERE/'results'/a.run_id)
