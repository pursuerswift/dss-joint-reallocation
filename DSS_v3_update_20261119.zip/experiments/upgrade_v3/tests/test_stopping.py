import unittest
import numpy as np
from scipy.optimize import linear_sum_assignment
from upgrade.comparators import score_stopping_path, generic_lp
from upgrade.flow import solve_path

class StoppingTests(unittest.TestCase):
    def test_every_prefix_against_individual_assignment(self):
        for seed in range(40):
            rng=np.random.default_rng(seed);s=rng.normal(size=16)
            b=np.arange(16)<8;t=rng.integers(0,4,16);g=rng.uniform(0,2,(4,4))
            e=np.flatnonzero(~b);e=e[np.lexsort((e,-s[e]))]
            l=np.flatnonzero(b);l=l[np.lexsort((l,s[l]))]
            values=[0.]
            for m in range(1,9):
                matrix=g[t[e[:m]][:,None],t[l[:m]][None,:]]
                x,y=linear_sum_assignment(matrix)
                values.append(s[e[:m]].sum()-s[l[:m]].sum()-matrix[x,y].sum())
            path=score_stopping_path(s,b,t,g,range(9))
            exact=solve_path(s,b,t,g,range(9))
            for cap in range(9):
                p=path[cap]
                self.assertAlmostEqual(p.objective,max(values[:cap+1]),places=8)
                self.assertLessEqual(p.m,cap)
                self.assertAlmostEqual(exact[cap].objective,generic_lp(s,b,t,g,cap).objective,places=7)

    def test_retention_and_global_ids(self):
        p=score_stopping_path(np.array([0.,.1]),np.array([True,False]),np.array([0,1]),np.ones((2,2)),[1])[1]
        self.assertEqual(p.m,0)

    def test_later_prefix_can_recover_after_negative_increment(self):
        s=np.array([0.,0.,.20,.19]);b=np.array([1,1,0,0],bool)
        t=np.array([0,1,0,1]);g=np.array([[.25,0.],[0.,.25]])
        path=score_stopping_path(s,b,t,g,[1,2])
        self.assertEqual(path[1].m,0)
        self.assertEqual(path[2].m,2)
        self.assertAlmostEqual(path[2].objective,.39)

    def test_scalar_frontiers_match_separate_cap_solutions(self):
        for seed in range(20):
            rng=np.random.default_rng(seed);s=rng.normal(size=18);b=np.arange(18)<7
            t=rng.integers(0,5,18);g=rng.uniform(0,2,(5,5))
            for solver in [solve_path,score_stopping_path]:
                plans,values=solver(s,b,t,g,[7],return_frontier=True)
                reference=solver(s,b,t,g,range(8))
                np.testing.assert_allclose(values,[reference[c].objective for c in range(8)],atol=1e-8)
                self.assertAlmostEqual(values[-1],plans[7].objective)

if __name__=='__main__':unittest.main()
