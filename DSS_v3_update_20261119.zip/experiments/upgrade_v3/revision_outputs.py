"""Generate publication figures and auditable tables from the complete paired run."""
from pathlib import Path
import shutil
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
DEST=HERE/'results/major_revision_20261118/revision'
PAPER=HERE.parents[1]/'papers/dss/v3_joint_reallocation'
def main():
    global DEST
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--run-id',default='major_revision_20261118')
    args=parser.parse_args();DEST=HERE/'results'/args.run_id/'revision'
    s=pd.read_csv(DEST/'summary.csv');c=pd.read_csv(DEST/'contrasts.csv')
    folder=DEST/'figures';folder.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    def save(fig,name):
        for ext in ['pdf','svg','png']:
            fig.savefig(folder/f'{name}.{ext}',dpi=220,bbox_inches='tight')
            shutil.copy2(folder/f'{name}.{ext}',PAPER/'figures'/f'{name}.{ext}')
        plt.close(fig)
    methods=['score_original','score_stopping','greedy_rematch','type_flow']
    h=s[(s.block=='headline')&(s.family=='compatibility')&(s.cap_share==1)].set_index('method').loc[methods]
    fig,ax=plt.subplots(figsize=(7.4,4.2),layout='constrained');x=np.arange(4)
    for j,(column,label,color) in enumerate([('gross','Gross benefit','#4682B4'),('cost','Transition cost','#D99A38'),('net','Net gain','#248375')]):
        ax.bar(x+(j-1)*.25,h[column],.25,label=label,color=color)
    ax.set_xticks(x,['Original\nscore','Score +\nstopping','Greedy +\nrematching','Type flow']);ax.set_ylabel('Value per 1,000 records');ax.legend(ncols=3,frameon=False)
    save(fig,'fair_decomposition')
    fig,axs=plt.subplots(1,2,figsize=(9,3.6),layout='constrained')
    for ax,fam,comp in zip(axs,['compatibility','specialist_flexible'],['score_stopping','greedy_rematch']):
        z=c[(c.block=='sensitivity')&(c.family==fam)&(c.cap_share==1)&(c.comparator==comp)]
        mat=z.pivot(index='strength',columns='noise',values='delta')
        limit=max(abs(mat.to_numpy()).max(),.01)
        im=ax.imshow(mat,origin='lower',aspect='auto',cmap='RdBu',vmin=-limit,vmax=limit)
        ax.set_xticks(range(len(mat.columns)),[f'{v:g}' for v in mat.columns]);ax.set_yticks(range(len(mat)),[f'{v:g}' for v in mat.index])
        ax.set_xlabel('Score-noise SD');ax.set_ylabel('Cost interaction strength');ax.set_title(fam.replace('_',' ').title())
        fig.colorbar(im,ax=ax,label='Flow − comparator / 1,000')
    save(fig,'cost_noise_heatmap')
    fig,axs=plt.subplots(1,2,figsize=(9,3.6),layout='constrained')
    for ax,fam,comp in zip(axs,['compatibility','specialist_flexible'],['score_stopping','greedy_rematch']):
        z=c[(c.block=='sensitivity')&(c.family==fam)&(c.strength==1)&(c.comparator==comp)]
        for share,g in z.groupby('cap_share'):
            g=g.sort_values('noise');ax.errorbar(g.noise,g.delta,yerr=1.96*g.mcse,marker='o',ms=3,label=f'{share:.0%} cap')
        ax.axhline(0,color='gray',lw=.7);ax.set_title(fam.replace('_',' ').title());ax.set_xlabel('Score-noise SD');ax.set_ylabel('True net difference / 1,000')
    axs[0].legend(frameon=False,fontsize=8);save(fig,'noise_budget_curves')
    fig,axs=plt.subplots(1,2,figsize=(9,3.6),layout='constrained')
    for ax,fam in zip(axs,['compatibility','specialist_flexible']):
        for method in methods:
            z=s[(s.block=='headline')&(s.family==fam)&(s.method==method)].sort_values('cap_share')
            ax.plot(z.cap_share,z.net,marker='o',label=method.replace('_',' '))
        ax.set_title(fam.replace('_',' ').title());ax.set_xlabel('Budget / incumbent count');ax.set_ylabel('True net gain / 1,000')
    axs[0].legend(frameon=False,fontsize=8);save(fig,'fair_frontiers')
    out=PAPER/'revision_20261118';out.mkdir(exist_ok=True)
    for name in ['summary.csv','contrasts.csv','validation.json']:
        shutil.copy2(DEST/name,out/name)
    h=s[(s.block=='headline')&(s.cap_share==1)]
    h.to_csv(out/'headline_decomposition.csv',index=False)
    print(h[['family','method','net','gross','cost','exchanges']].to_string(index=False))
if __name__=='__main__':main()
