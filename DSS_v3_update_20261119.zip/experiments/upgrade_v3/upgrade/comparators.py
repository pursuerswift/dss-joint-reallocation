"""Full-cost comparators: an independent sparse LP and greedy selection/rematching."""
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from .flow import Plan,retention,rematch


def generic_lp(score,base,types,gamma,cap):
    """Integral min-cost flow LP with record arcs, type arcs and an unused-cap arc.

    All costs remain floating point. The source supplies cap units; unused units
    pass directly to the sink. Network integrality supplies a discrete solution.
    """
    e,l=np.flatnonzero(~base),np.flatnonzero(base)
    ne,nl=len(e),len(l);K=len(gamma)
    cap=min(int(cap),ne,nl)
    if cap<=0:return retention()
    z0=ne+nl;nv=z0+K*K+1
    zi=np.arange(K*K)+z0
    # entrant balance: -x + outflow = 0; leaver balance: inflow - y = 0.
    rr=np.r_[types[e],np.full(ne,2*K),K+types[l],np.repeat(np.arange(K),K),K+np.tile(np.arange(K),K),2*K]
    cc=np.r_[np.arange(ne),np.arange(ne),ne+np.arange(nl),zi,zi,nv-1]
    vv=np.r_[-np.ones(ne),np.ones(ne),-np.ones(nl),np.ones(K*K),np.ones(K*K),1.]
    # With -x+z=0 and -y+z=0, reversing all leaver rows gives incidence signs.
    A=coo_matrix((vv,(rr,cc)),shape=(2*K+1,nv)).tocsc()
    b=np.r_[np.zeros(2*K),float(cap)]
    cost=np.r_[-score[e],score[l],gamma.ravel(),0.]
    bounds=np.column_stack([np.zeros(nv),np.r_[np.ones(ne+nl),np.full(K*K+1,cap)]])
    opt=linprog(cost,A_eq=A,b_eq=b,bounds=bounds,method='highs',
                options={'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8})
    if not opt.success:raise RuntimeError(opt.message)
    integer=np.rint(opt.x).astype(int)
    if np.max(np.abs(opt.x-integer))>1e-6:raise ArithmeticError('Fractional network LP solution')
    es=[e[(types[e]==a)&(integer[:ne]>0)] for a in range(K)]
    ls=[l[(types[l]==a)&(integer[ne:z0]>0)] for a in range(K)]
    allocation=integer[z0:-1].reshape(K,K)
    pe=np.zeros(K,int);pl=np.zeros(K,int);pairs=[]
    for a in range(K):
        for btype in range(K):
            for _ in range(allocation[a,btype]):
                pairs.append((es[a][pe[a]],ls[btype][pl[btype]]));pe[a]+=1;pl[btype]+=1
    return Plan(np.asarray(pairs,int).reshape(-1,2),float(np.sum(allocation*gamma)),
                key='generic_lp',method='generic_lp',objective=float(-opt.fun))


def greedy_rematch(score,base,types,gamma,cap):
    """Choose best available net-gain pair, then optimally rematch selected lists."""
    K=len(gamma);e=np.flatnonzero(~base);l=np.flatnonzero(base)
    es=[e[types[e]==a] for a in range(K)];ls=[l[types[l]==a] for a in range(K)]
    es=[a[np.lexsort((a,-score[a]))] for a in es]
    ls=[a[np.lexsort((a,score[a]))] for a in ls]
    pe=np.zeros(K,int);pl=np.zeros(K,int);picked_e=[];picked_l=[]
    for _ in range(min(int(cap),len(e),len(l))):
        ev=np.array([score[a[pe[t]]] if pe[t]<len(a) else -np.inf for t,a in enumerate(es)])
        lv=np.array([score[a[pl[t]]] if pl[t]<len(a) else np.inf for t,a in enumerate(ls)])
        margin=ev[:,None]-lv[None,:]-gamma
        a,b=np.unravel_index(np.argmax(margin),margin.shape)
        if margin[a,b]<=1e-11:break
        picked_e.append(es[a][pe[a]]);picked_l.append(ls[b][pl[b]])
        pe[a]+=1;pl[b]+=1
    p=rematch(picked_e,picked_l,types,gamma)
    p.key=p.method='greedy_rematch'
    return p


def score_stopping_path(score, base, types, gamma, caps, return_frontier=False):
    """Score prefixes, optimal transportation at EVERY count, then best net stop.

    Incremental min-cost transportation adds one supply and demand unit. A
    shortest alternating residual path restores the optimum; unlike net flow,
    prefix objectives need not be concave, so never stop at a negative increment.
    Final selected prefixes are independently reconstructed with HiGHS rematch.
    Ties choose the smaller count. No true benefits enter selection.
    return_frontier returns (plans, scalar_values), including every integer cap.
    The scalar prefix frontier is restricted to ranked endpoints, not globally
    optimal over arbitrary endpoints. Only requested plans are materialized.
    """
    score=np.asarray(score); base=np.asarray(base,dtype=bool)
    e=np.flatnonzero(~base); l=np.flatnonzero(base)
    e=e[np.lexsort((e,-score[e]))]; l=l[np.lexsort((l,score[l]))]
    caps=sorted(set(max(0,min(int(c),len(e),len(l))) for c in caps))
    if not caps:return ({},np.array([0.])) if return_frontier else {}
    K=len(gamma); z=np.zeros((K,K),int); costs=[0.]; values=[0.]
    gross=0.
    for m in range(1,max(caps)+1):
        source=int(types[e[m-1]]); target=K+int(types[l[m-1]])
        a=np.full((2*K,2*K),np.inf); a[:K,K:]=gamma
        a[K:,:K]=np.where(z.T>0,-gamma.T,np.inf)
        dist=np.full(2*K,np.inf);dist[source]=0.;prev=np.full(2*K,-1,int)
        for _ in range(2*K-1):
            candidates=dist[:,None]+a
            parent=np.argmin(candidates,axis=0);new=candidates[parent,np.arange(2*K)]
            improve=new<dist-1e-12
            if not improve.any():break
            dist[improve]=new[improve];prev[improve]=parent[improve]
        node=target;seen=set()
        while node!=source:
            if node in seen or prev[node]<0:raise ArithmeticError('Invalid prefix residual path')
            seen.add(node);u=int(prev[node])
            if u<K:z[u,node-K]+=1
            else:z[node,u-K]-=1
            node=u
        gross+=score[e[m-1]]-score[l[m-1]]
        costs.append(float(np.sum(z*gamma)));values.append(gross-costs[-1])
    out={};best=0;best_counts=[0]
    for m in range(1,len(values)):
        if values[m]>values[best]+1e-11:best=m
        best_counts.append(best)
    for cap in caps:
        best=best_counts[cap]
        p=rematch(e[:best],l[:best],types,gamma)
        if abs(p.cost-costs[best])>1e-7:raise ArithmeticError('Prefix cost disagrees with LP')
        p.key=p.method='score_stopping';p.objective=values[best];out[cap]=p
    if return_frontier:
        return out,np.asarray(values)[best_counts]
    return out
