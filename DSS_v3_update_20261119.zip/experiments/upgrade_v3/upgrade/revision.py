"""Paired stopping, mechanism and input-error experiments, November 2026."""
from concurrent.futures import ProcessPoolExecutor, as_completed
import json, time
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from .flow import topk, solve_path, rematch
from .comparators import score_stopping_path, greedy_rematch, generic_lp
from .conflict import population as conflict_population
from .inference import evaluate

def population(c, rep):
    if c['family'] in ['specialist_flexible','random_asymmetric']:
        return conflict_population(dict(seed=2026111801,quota=.4),c['family'],c['n'],c['k'],rep,c['strength'],c['noise'])
    n=c['n'];k=c['k']
    rng=np.random.default_rng(np.random.SeedSequence([20261117,n,rep]))
    if k==4:ty=rng.integers(0,4,n)
    else:
        prob=np.ones(6)/6 if c['balance']=='balanced' else np.array([.10,.15,.25,.25,.15,.10])
        ty=rng.choice(6,n,p=prob)
    priority=rng.normal(size=n);priority[ty>=k//2]=-np.inf
    base=topk(priority,np.arange(n),.2)
    means=[.02,.04,.16,.10] if k==4 else [.02,.04,.03,.16,.10,.07]
    tau=np.array(means)[ty]+.015*np.tanh(rng.normal(size=n))
    score=tau+c['noise']*rng.normal(size=n);groups=np.arange(k)%(k//2)
    if c['family']=='directional':h=np.array([[0.,.45,1.],[.9,0.,.55],[.35,.85,0.]])
    elif c['family']=='distance':h=np.abs(np.array([0.,.35,1.])[:,None]-np.array([0.,.35,1.])[None,:])
    else:h=1-np.eye(k//2)
    gamma=.005+.18*c['strength']*h[groups[:,None],groups[None,:]]
    return score,base,ty,gamma,tau

def cell(task):
    c,reps=task;rows=[]
    with threadpool_limits(limits=1):
        for rep in range(reps):
            s,b,t,g,tau=population(c,rep)
            rng=np.random.default_rng(np.random.SeedSequence([901,c['n'],c['k'],rep]))
            estimated=np.maximum(0,g+c['cost_error']*rng.uniform(-1,1,g.shape))
            caps=[int(b.sum()*a) for a in [.25,.5,.75,1.]]
            stop=score_stopping_path(s,b,t,estimated,caps);flow=solve_path(s,b,t,estimated,caps)
            e=np.flatnonzero(~b);e=e[np.lexsort((e,-s[e]))];l=np.flatnonzero(b);l=l[np.lexsort((l,s[l]))]
            for share,cap in zip([.25,.5,.75,1.],caps):
                greedy=greedy_rematch(s,b,t,estimated,cap)
                m=min(cap,int((s[e[:len(l)]]-s[l]>0).sum()))
                plans={'score_original':rematch(e[:m],l[:m],t,estimated),'score_stopping':stop[cap],
                    'greedy_rematch':greedy,'type_flow':flow[cap],
                    'flow_at_greedy_count':solve_path(s,b,t,estimated,[greedy.m])[greedy.m]}
                if rep==0:
                    lp=generic_lp(s,b,t,estimated,cap)
                    assert abs(evaluate(lp,s)['net']-evaluate(flow[cap],s)['net'])<1e-7
                for method,p in plans.items():
                    pred=evaluate(p,s)['net']*1000
                    # Evaluate the selected transfers at true costs, WITHOUT oracle rematching.
                    p.cost=float(g[t[p.pairs[:,0]],t[p.pairs[:,1]]].sum())
                    v=evaluate(p,tau)
                    rows.append(dict(**c,rep=rep,cap_share=share,cap=cap,method=method,exchanges=p.m,
                        true_net=1000*v['net'],gross=1000*v['gross'],cost=1000*v['cost'],predicted_net=pred,
                        reverse=p.reverse_augmentations))
    return rows

KEYS=['block','family','n','k','balance','strength','noise','cost_error','cap_share']
def run(cfg,dest,resume=False,workers=4):
    folder=dest/'cells';folder.mkdir(exist_ok=True)
    tasks=[]
    def add(block,family,n,k,strength,noise,reps,balance='balanced',cost_error=0.):
        tasks.append((dict(block=block,family=family,n=n,k=k,balance=balance,strength=strength,noise=noise,cost_error=cost_error),reps))
    add('headline','compatibility',6000,4,1.,.04,cfg['headline_reps'])
    add('headline','specialist_flexible',8000,12,1.,0.,cfg['conflict_reps'])
    for family,k in [('compatibility',4),('specialist_flexible',6)]:
        for strength in cfg['strengths']:
            for noise in cfg['noise']:
                add('sensitivity',family,cfg['n'],k,strength,noise,cfg['repetitions'])
    for family in ['compatibility','directional','distance','specialist_flexible','random_asymmetric']:
        for strength in [.25,1.]:
            for err in [0.,.02]:
                for balance in (['balanced','skewed'] if family in ['compatibility','directional','distance'] else ['balanced']):
                    add('robustness',family,cfg['n'],6,strength,.04,cfg['repetitions'],balance,err)
    (dest/'cells_design.json').write_text(json.dumps(tasks,indent=2))
    with ProcessPoolExecutor(max_workers=workers) as pool:
        pending={pool.submit(cell,t):i for i,t in enumerate(tasks) if not(resume and (folder/f'{i:03}.csv').exists())}
        for f in as_completed(pending):
            i=pending[f];pd.DataFrame(f.result()).to_csv(folder/f'{i:03}.csv',index=False)
            print(f'revision cell {i+1}/{len(tasks)}',flush=True)
    d=pd.concat([pd.read_csv(p) for p in sorted(folder.glob('*.csv'))],ignore_index=True)
    d.to_csv(dest/'replicates.csv',index=False)
    d.groupby(KEYS+['method']).agg(net=('true_net','mean'),gross=('gross','mean'),cost=('cost','mean'),
        exchanges=('exchanges','mean'),predicted=('predicted_net','mean'),reps=('rep','size')).reset_index().to_csv(dest/'summary.csv',index=False)
    w=d.pivot(index=KEYS+['rep'],columns='method',values='true_net');parts=[]
    for method in ['score_original','score_stopping','greedy_rematch','flow_at_greedy_count']:
        x=(w.type_flow-w[method]).rename('difference').reset_index()
        x['baseline']=w[method].values
        a=x.groupby(KEYS).agg(delta=('difference','mean'),sd=('difference','std'),reps=('rep','size'),baseline=('baseline','mean')).reset_index()
        a['mcse']=a.sd/np.sqrt(a.reps);a['relative_percent']=np.where(a.baseline>1e-8,100*a.delta/a.baseline,np.nan)
        a['comparator']=method;parts.append(a)
    pd.concat(parts).to_csv(dest/'contrasts.csv',index=False)
    residual=float((d.true_net-d.gross+d.cost).abs().max())
    assert residual<1e-8
    (dest/'validation.json').write_text(json.dumps(dict(rows=len(d),cells=len(tasks),net_identity_error=residual,lp_check='first replicate at every cell and budget'),indent=2))
