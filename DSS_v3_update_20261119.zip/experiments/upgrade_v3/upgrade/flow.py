"""Exact type-cost exchange with dense potential-based shortest paths.

O(n log n + (r+1) K^2) for one cap; explicit multi-cap outputs add their size.
All exposed pairs use GLOBAL record indices.
Successive plans may reassign pair edges. Source/sink selection is monotone.
"""
from dataclasses import dataclass, field
import numpy as np
from scipy.optimize import linprog


@dataclass
class Plan:
    pairs: np.ndarray
    cost: float
    key: str = ''
    method: str = ''
    cap: float = 0.0
    eta: float = 0.0
    objective: float = 0.0
    marginals: list = field(default_factory=list)
    reverse_augmentations: int = 0
    reverse_arc_traversals: int = 0

    @property
    def m(self):
        return len(self.pairs)

    def weights(self, n):
        w = np.zeros(n)
        if self.m:
            w[self.pairs[:, 0]] = 1
            w[self.pairs[:, 1]] = -1
        return w


def retention():
    return Plan(np.empty((0, 2), dtype=int), 0.0, 'retain', 'retain')


def topk(score, ids, quota):
    n = len(score)
    if not 0 <= quota <= 1 or len(np.unique(ids)) != n:
        raise ValueError('Quota or unique IDs invalid')
    p = np.zeros(n, dtype=bool)
    p[np.lexsort((ids, -np.asarray(score)))[:int(np.floor(n * quota))]] = True
    return p


def _validate(score, base, types, gamma, variance, penalty):
    score, base = np.asarray(score, float), np.asarray(base)
    types, gamma = np.asarray(types, int), np.asarray(gamma, float)
    if score.ndim != 1 or base.shape != score.shape or types.shape != score.shape:
        raise ValueError('Record arrays must be aligned vectors')
    if not np.isin(base, [0, 1]).all() or not np.isfinite(score).all():
        raise ValueError('Scores finite; incumbent binary')
    K = len(gamma)
    if gamma.shape != (K, K) or not np.isfinite(gamma).all() or (gamma < 0).any():
        raise ValueError('Costs must be a finite nonnegative square matrix')
    if (types < 0).any() or (types >= K).any():
        raise ValueError('Type index outside matrix')
    v = np.zeros(len(score)) if variance is None else np.asarray(variance, float)
    if v.shape != score.shape or not np.isfinite(v).all() or (v < 0).any() or penalty < 0:
        raise ValueError('Invalid design variance or penalty')
    return score, base.astype(bool), types, gamma, v


def solve_path(score, base, types, gamma, caps, variance=None, penalty=0.0, return_frontier=False):
    """Return exact solutions to score gain - cost - penalty*sum(variance).

    Each cap is an integer exchange upper bound. Stopping is BEFORE the first
    non-improving augmentation. Dijkstra visits all reachable nodes so the
    potential update remains feasible after residual reassignments.
    return_frontier returns (plans, scalar_values) for all integer upper bounds
    through max(caps), without materializing additional record-level plans.
    """
    s, b, ty, g, v = _validate(score, base, types, gamma, variance, penalty)
    K = len(g)
    caps = sorted(set(max(0, min(int(c), int(b.sum()), int((~b).sum()))) for c in caps))
    if not caps:
        return ({},np.array([0.])) if return_frontier else {}
    ae, bx = s - penalty*v, s + penalty*v
    ei, lj = np.flatnonzero(~b), np.flatnonzero(b)
    eo = ei[np.lexsort((ei, -ae[ei], ty[ei]))]
    lo = lj[np.lexsort((lj, bx[lj], ty[lj]))]
    entrants = np.split(eo, np.cumsum(np.bincount(ty[ei], minlength=K))[:-1])
    leavers = np.split(lo, np.cumsum(np.bincount(ty[lj], minlength=K))[:-1])
    ec, lc = np.zeros(K, int), np.zeros(K, int)
    allocation = np.zeros((K, K), int)
    S, T, V = 2*K, 2*K+1, 2*K+2

    def adjacency():
        a = np.full((V, V), np.inf)
        for t in range(K):
            if ec[t] < len(entrants[t]):
                a[S, t] = -ae[entrants[t][ec[t]]]
            if ec[t]:
                a[t, S] = ae[entrants[t][ec[t]-1]]
            if lc[t] < len(leavers[t]):
                a[K+t, T] = bx[leavers[t][lc[t]]]
            if lc[t]:
                a[T, K+t] = -bx[leavers[t][lc[t]-1]]
        a[:K, K:2*K] = g
        a[K:2*K, :K] = np.where(allocation.T > 0, -g.T, np.inf)
        return a

    # Initial graph is acyclic, hence shortest distances in three layers.
    a = adjacency()
    pot = np.zeros(V)
    pot[:K] = a[S, :K]
    pot[K:2*K] = np.min(pot[:K, None] + g, axis=0)
    pot[T] = np.min(pot[K:2*K] + a[K:2*K, T])
    pot[~np.isfinite(pot)] = 0
    answers, marginals, m = {}, [], 0
    reverse_augmentations, reverse_arc_traversals = 0, 0

    def snapshot():
        pairs, pe, pl = [], np.zeros(K, int), np.zeros(K, int)
        for t in range(K):
            for u in range(K):
                for _ in range(allocation[t, u]):
                    pairs.append((entrants[t][pe[t]], leavers[u][pl[u]]))
                    pe[t] += 1
                    pl[u] += 1
        pairs = np.asarray(pairs, int).reshape(-1, 2)
        cost = float(np.sum(allocation*g))
        return Plan(pairs, cost, eta=penalty, objective=float(sum(marginals)),
                    marginals=list(marginals), reverse_augmentations=reverse_augmentations,
                    reverse_arc_traversals=reverse_arc_traversals)

    if 0 in caps:
        answers[0] = snapshot()
    while m < max(caps):
        a = adjacency()
        reduced = a + pot[:, None] - pot[None, :]
        dist, prev, done = np.full(V, np.inf), np.full(V, -1, int), np.zeros(V, bool)
        dist[S] = 0
        for _ in range(V):
            u = int(np.argmin(np.where(done, np.inf, dist)))
            if not np.isfinite(dist[u]):
                break
            done[u] = True
            finite = np.isfinite(reduced[u]) & (~done)
            if finite.any() and reduced[u, finite].min() < -1e-8:
                raise ArithmeticError('Infeasible shortest-path potentials')
            nd = dist[u] + np.maximum(reduced[u], 0)
            improve = finite & (nd < dist - 1e-12)
            dist[improve], prev[improve] = nd[improve], u
        marginal_cost = dist[T] - pot[S] + pot[T]
        if not np.isfinite(marginal_cost) or marginal_cost >= -1e-11:
            break
        reachable = np.isfinite(dist)
        pot[reachable] += dist[reachable]
        node = T
        path_reversals = 0
        while node != S:
            u = int(prev[node])
            if u < 0:
                raise ArithmeticError('Broken augmenting path')
            if u == S: ec[node] += 1
            elif node == S: ec[u] -= 1
            elif node == T: lc[u-K] += 1
            elif u == T: lc[node-K] -= 1
            elif u < K and K <= node < 2*K: allocation[u, node-K] += 1
            elif K <= u < 2*K and node < K:
                allocation[node, u-K] -= 1
                path_reversals += 1
            else: raise ArithmeticError('Unexpected residual edge')
            node = u
        m += 1
        reverse_augmentations += int(path_reversals > 0)
        reverse_arc_traversals += path_reversals
        marginals.append(float(-marginal_cost))
        if m in caps:
            answers[m] = snapshot()
    final = snapshot()
    for c in caps:
        if c not in answers:
            answers[c] = Plan(final.pairs.copy(), final.cost, eta=penalty,
                              objective=final.objective, marginals=list(final.marginals),
                              reverse_augmentations=final.reverse_augmentations,
                              reverse_arc_traversals=final.reverse_arc_traversals)
    if return_frontier:
        values=np.r_[0.,np.cumsum(marginals)]
        return answers,np.pad(values,(0,max(caps)+1-len(values)),mode='edge')
    return answers


def rematch(entrants, leavers, types, gamma):
    """Minimum true cost conditional on selected recipients, a strong baseline."""
    ei, lj = np.asarray(entrants, int), np.asarray(leavers, int)
    if len(ei) != len(lj):
        raise ValueError('Unequal exchange sides')
    if not len(ei): return retention()
    K = len(gamma)
    ec, lc = np.bincount(types[ei], minlength=K), np.bincount(types[lj], minlength=K)
    A = np.zeros((2*K, K*K))
    for t in range(K):
        A[t, t*K:(t+1)*K] = 1
        A[K+t, t::K] = 1
    opt = linprog(gamma.ravel(), A_eq=A, b_eq=np.r_[ec, lc], bounds=(0, None), method='highs')
    if not opt.success: raise RuntimeError(opt.message)
    x = np.rint(opt.x).astype(int).reshape(K, K)
    if not (np.array_equal(x.sum(1), ec) and np.array_equal(x.sum(0), lc)):
        raise ArithmeticError('Nonintegral transportation solution')
    es, ls = [ei[types[ei] == t] for t in range(K)], [lj[types[lj] == t] for t in range(K)]
    pe, pl, pairs = np.zeros(K, int), np.zeros(K, int), []
    for t in range(K):
        for u in range(K):
            for _ in range(x[t, u]):
                pairs.append((es[t][pe[t]], ls[u][pl[u]]))
                pe[t] += 1
                pl[u] += 1
    return Plan(np.asarray(pairs, int), float(np.sum(x*gamma)))
