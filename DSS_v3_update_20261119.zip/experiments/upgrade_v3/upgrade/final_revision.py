"""Focused submission checks: paired timing and higher-replication mechanisms."""
import json,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from .revision import cell,KEYS,population
from .flow import solve_path,topk
from .comparators import score_stopping_path
from .inference import evaluate

def summarize(d,dest):
    d.to_csv(dest/'replicates.csv',index=False)
    d.groupby(KEYS+['method']).agg(net=('true_net','mean'),gross=('gross','mean'),cost=('cost','mean'),
        exchanges=('exchanges','mean'),predicted=('predicted_net','mean'),reps=('rep','size')).reset_index().to_csv(dest/'summary.csv',index=False)
    w=d.pivot(index=KEYS+['rep'],columns='method',values='true_net');parts=[]
    for method in ['score_original','score_stopping','greedy_rematch','flow_at_greedy_count']:
        x=(w.type_flow-w[method]).rename('difference').reset_index();x['baseline']=w[method].values
        a=x.groupby(KEYS).agg(delta=('difference','mean'),sd=('difference','std'),reps=('rep','size'),baseline=('baseline','mean')).reset_index()
        a['mcse']=a.sd/np.sqrt(a.reps);a['lower']=a.delta-1.96*a.mcse;a['upper']=a.delta+1.96*a.mcse
        a['relative_percent']=np.where(a.baseline>1e-8,100*a.delta/a.baseline,np.nan);a['comparator']=method;parts.append(a)
    pd.concat(parts).to_csv(dest/'contrasts.csv',index=False)
    assert np.max(abs(d.true_net-d.gross+d.cost))<1e-8

def run_focus(cfg,dest,resume=False,workers=4):
    tasks=[]
    for family,n,k,strength,noise in [('compatibility',6000,4,.5,.04),('compatibility',600,4,1,.04),
        ('compatibility',600,4,1,.08)]+[('specialist_flexible',600,6,1,v) for v in [.01,.02,.04,.08]]:
        tasks.append((dict(block='final_focus',family=family,n=n,k=k,strength=strength,noise=noise,balance='balanced',cost_error=0.),cfg['focus_repetitions']))
    folder=dest/'cells';folder.mkdir(exist_ok=True)
    (dest/'cells_design.json').write_text(json.dumps(tasks,indent=2))
    with ProcessPoolExecutor(max_workers=workers) as pool:
        fs={pool.submit(cell,t):i for i,t in enumerate(tasks) if not(resume and (folder/f'{i}.csv').exists())}
        for f in as_completed(fs):
            pd.DataFrame(f.result()).to_csv(folder/f'{fs[f]}.csv',index=False);print('focus cell',fs[f],flush=True)
    summarize(pd.concat([pd.read_csv(folder/f'{i}.csv') for i in range(len(tasks))]),dest)

def run_timing(cfg,dest,resume=False,workers=1):
    if resume:raise ValueError('Timing runs are sequential and must use a fresh run ID')
    rows=[];frontiers=[]
    tasks=[('random',n,k,rep) for n in cfg['sizes'] for k in cfg['types'] for rep in range(cfg['timing_repetitions'])]
    tasks += [('competition',8000,12,rep) for rep in range(cfg['timing_repetitions'])]
    with threadpool_limits(limits=1):
        # Warm both libraries outside timing, then regenerate every measured input.
        for solver in [solve_path,score_stopping_path]:solver(np.array([0.,1.]),np.array([True,False]),np.array([0,0]),np.zeros((1,1)),[1])
        for family,n,k,rep in tasks:
            if family=='competition':
                s,b,t,g,tau=population(dict(family='specialist_flexible',n=n,k=k,strength=1.,noise=0.),rep)
            else:
                rng=np.random.default_rng(np.random.SeedSequence([20261119,n,k,rep]))
                tau=rng.normal(0,.1,n);s=tau+.04*rng.normal(size=n)
                b=topk(rng.normal(size=n),np.arange(n),.4);t=rng.integers(k,size=n);g=rng.uniform(.005,.185,(k,k))
            cap=int(b.sum())
            jobs=[(method,mode) for method in ['score_stopping','type_flow'] for mode in ['plan','frontier']]
            # Balanced rotations vary method and output-mode order; no parallel timing.
            shift=rep%4;jobs=jobs[shift:]+jobs[:shift]
            values={}
            for method,mode in jobs:
                solver=solve_path if method=='type_flow' else score_stopping_path
                start=time.perf_counter();result=solver(s,b,t,g,[cap],return_frontier=(mode=='frontier'))
                seconds=time.perf_counter()-start
                if mode=='frontier':
                    plans,v=result;values[method]=v
                    frontiers.extend(dict(family=family,n=n,k=k,rep=rep,method=method,cap=i,objective=float(x)) for i,x in enumerate(v))
                else:plans=result
                p=plans[cap]
                rows.append(dict(family=family,n=n,k=k,rep=rep,method=method,mode=mode,seconds=seconds,
                    cap=cap,incumbents=int(b.sum()),entrants=int((~b).sum()),exchanges=p.m,
                    objective=p.objective,true_net=1000*evaluate(p,tau)['net']))
            assert np.min(values['type_flow']-values['score_stopping'])>=-1e-7
            if rep==cfg['timing_repetitions']-1:print('timing',family,n,k,flush=True)
    d=pd.DataFrame(rows);d.to_csv(dest/'runtime.csv',index=False)
    pd.DataFrame(frontiers).to_csv(dest/'frontiers.csv',index=False)
    d.groupby(['family','n','k','method','mode']).agg(seconds=('seconds','mean'),sd=('seconds','std'),
        minimum=('seconds','min'),maximum=('seconds','max'),objective=('objective','mean'),
        true_net=('true_net','mean'),exchanges=('exchanges','mean')).reset_index().to_csv(dest/'summary.csv',index=False)
