"""Source tables and focused Monte Carlo figure for the November 19 revision."""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[2];P=ROOT/'papers/dss/v3_joint_reallocation'
RUN=ROOT/'experiments/upgrade_v3/results/submission_final_20261119'
OUT=P/'revision_20261119'

def markdown(d):
    return '| '+' | '.join(d.columns)+' |\n| '+' | '.join(['---']*len(d.columns))+' |\n'+''.join('| '+' | '.join(str(v) for v in row)+' |\n' for row in d.itertuples(index=False,name=None))

def main():
    OUT.mkdir(exist_ok=True)
    s=pd.read_csv(RUN/'final_focus/summary.csv');c=pd.read_csv(RUN/'final_focus/contrasts.csv')
    old=pd.read_csv(ROOT/'experiments/upgrade_v3/results/major_revision_20261118/revision/summary.csv')
    high=c[(c.n==600)&(c.cap_share==1)&(((c.family=='compatibility')&(c.comparator=='score_stopping'))|((c.family=='specialist_flexible')&(c.comparator=='greedy_rematch')))]
    high=high.sort_values(['family','noise']);high.to_csv(OUT/'focused_100.csv',index=False)
    table=pd.DataFrame({'Setting':high.family.map({'compatibility':'Compatibility','specialist_flexible':'Competition'}),
        'Noise':high.noise.map(lambda x:f'{x:.2f}'),'Difference':high.delta.map(lambda x:f'{x:.3f}'),
        'MCSE':high.mcse.map(lambda x:f'{x:.3f}'),'95% MC interval':[f'[{a:.3f}, {b:.3f}]' for a,b in zip(high.lower,high.upper)],
        'Change (%)':high.relative_percent.map(lambda x:f'{x:.2f}')})
    (OUT/'focused_table.md').write_text(markdown(table),encoding='utf-8')
    combined=pd.concat([s[(s.n==6000)&(s.cap_share==1)],old[(old.block=='headline')&(old.n==6000)&(old.cap_share==1)]])
    combined=combined[combined.method!='flow_at_greedy_count'].sort_values(['strength','method'])
    combined.to_csv(OUT/'moderate_strong.csv',index=False)
    names={'score_original':'Score','score_stopping':'Stop','greedy_rematch':'Greedy','type_flow':'Flow'}
    table=pd.DataFrame({'Cost strength':combined.strength,'Method':combined.method.map(names),'Gross':combined.gross.map(lambda x:f'{x:.3f}'),
        'Cost':combined.cost.map(lambda x:f'{x:.3f}'),'Net':combined.net.map(lambda x:f'{x:.3f}'),
        'Exchanges':combined.exchanges.map(lambda x:f'{x:.1f}'),'Score net':combined.predicted.map(lambda x:f'{x:.3f}')})
    (OUT/'moderate_table.md').write_text(markdown(table),encoding='utf-8')
    c[(c.n==6000)&(c.cap_share==1)].to_csv(OUT/'moderate_contrasts.csv',index=False)
    t=pd.read_csv(RUN/'final_timing/summary.csv');rows=[]
    for (family,n,k),g in t.groupby(['family','n','k']):
        z=g.set_index(['method','mode']);a=z.loc[('score_stopping','plan')];b=z.loc[('type_flow','plan')]
        rows.append(dict(family=family,n=n,k=k,stop_plan=a.seconds,flow_plan=b.seconds,
            stop_frontier=z.loc[('score_stopping','frontier')].seconds,flow_frontier=z.loc[('type_flow','frontier')].seconds,
            score_difference=1000*(b.objective-a.objective)/n,true_difference=b.true_net-a.true_net,
            stop_exchanges=a.exchanges,flow_exchanges=b.exchanges,stop_net=a.true_net,flow_net=b.true_net))
    summary=pd.DataFrame(rows);summary.to_csv(OUT/'timing_comparison.csv',index=False)
    mainrows=summary[summary.n==8000]
    table=pd.DataFrame({'Types / setting':[f'{k} / '+('comp.' if f=='competition' else 'random') for k,f in zip(mainrows.k,mainrows.family)],
        'Plan Stop / Flow':[f'{a:.3f} / {b:.3f}' for a,b in zip(mainrows.stop_plan,mainrows.flow_plan)],
        'Frontier Stop / Flow':[f'{a:.3f} / {b:.3f}' for a,b in zip(mainrows.stop_frontier,mainrows.flow_frontier)],
        'Score gain':mainrows.score_difference.map(lambda x:f'{x:.3f}'),'True gain':mainrows.true_difference.map(lambda x:f'{x:.3f}'),
        'Count Stop / Flow':[f'{a:.0f} / {b:.0f}' for a,b in zip(mainrows.stop_exchanges,mainrows.flow_exchanges)]})
    (OUT/'timing_table.md').write_text(markdown(table),encoding='utf-8')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axs=plt.subplots(1,2,figsize=(8.2,3.4),layout='constrained')
    for ax,family in zip(axs,['compatibility','specialist_flexible']):
        g=high[high.family==family]
        ax.errorbar(g.noise,g.delta,yerr=1.96*g.mcse,fmt='o',capsize=4,color='#257b83')
        ax.axhline(0,color='gray',lw=.7);ax.set_xlabel('Score-noise SD');ax.set_ylabel('True net difference / 1,000')
        ax.set_title('Compatibility vs Stop' if family=='compatibility' else 'Competition vs Greedy')
    for ext in ['pdf','png','svg']:fig.savefig(P/'figures'/f'focused_precision.{ext}',dpi=220)
    plt.close(fig)
    # The original heatmap is unchanged; these higher-repetition values are separate.
    print(table.to_string(index=False));print(high[['family','noise','delta','mcse','lower','upper','relative_percent']].to_string(index=False))
if __name__=='__main__':main()
