param(
    [ValidateSet('simulate','empirical','scale','figures','all')][string]$Stage = 'all',
    [string]$RunId = ('run_' + (Get-Date -Format 'yyyyMMdd_HHmmss')),
    [ValidateSet('pilot','full')][string]$Profile = 'pilot',
    [int]$Workers = 1,
    [switch]$Resume,
    [switch]$Smoke
)
$projectRoot = $PSScriptRoot
while (-not (Test-Path -LiteralPath (Join-Path $projectRoot '.tools\extension_v2_conda_clean\python.exe'))) {
    $nextParent = Split-Path -Parent $projectRoot
    if (-not $nextParent -or $nextParent -eq $projectRoot) { throw 'Project Python runtime not found.' }
    $projectRoot = $nextParent
}
$pythonExe = Join-Path $projectRoot '.tools\extension_v2_conda_clean\python.exe'
$runArgs = @((Join-Path $PSScriptRoot 'run.py'), $Stage, '--run-id', $RunId, '--config', (Join-Path $PSScriptRoot "config\$Profile.json"))
$runArgs += @('--workers', $Workers)
if ($Resume) { $runArgs += '--resume' }
if ($Smoke) { $runArgs += '--smoke' }
& $pythonExe @runArgs
exit $LASTEXITCODE
