# 路径对照（2026-11-16 重排）

目录已按「论文 → 版本」重排。旧路径全部失效，对照如下。

## 当前稿

| 旧路径 | 新路径 |
|---|---|
| `dss_revision_20261112_r6/` | [`papers/dss/r6/`](papers/dss/r6/)（现为冻结基线，短入口 [`baseline/`](baseline/)） |
| — | [`papers/dss/v2_c1c2/`](papers/dss/v2_c1c2/)（当前工作区，短入口 [`current/`](current/)） |

## DSS

| 旧路径 | 新路径 |
|---|---|
| `dss_revision_20261112_r5/` | [`papers/dss/r5/`](papers/dss/r5/) |
| `resubmission_planning_20261111/` | [`papers/dss/planning_20261111/`](papers/dss/planning_20261111/) |
| `dss_revision_20261111/`、`_r2/`、`_r3/`、`_r4/` | 已于 2026-11-16 删除（由 R5、R6 覆盖） |

## JMA

| 旧路径 | 新路径 |
|---|---|
| `jma_revision/` | [`papers/jma/2026-10-18_revised/`](papers/jma/2026-10-18_revised/) |
| `jma_revision_round2/` | [`papers/jma/2026-10-20_round2/`](papers/jma/2026-10-20_round2/) |
| `jma_language_polishing/` | [`papers/jma/2026-10-20_language_polishing/`](papers/jma/2026-10-20_language_polishing/) |
| `revision_output/` | [`papers/jma/2026-10-22_round1/`](papers/jma/2026-10-22_round1/) |
| `revision_output_round3/` | [`papers/jma/2026-10-22_round3/`](papers/jma/2026-10-22_round3/) |
| `revision_output_round4/` | [`papers/jma/2026-10-26_round4/`](papers/jma/2026-10-26_round4/) |
| `revision_output_round5/` | [`papers/jma/2026-11-03_round5/`](papers/jma/2026-11-03_round5/) |
| `history/JMA/2026-10-14_rebuild/` | [`papers/jma/2026-10-14_rebuild/`](papers/jma/2026-10-14_rebuild/) |
| `history/JMA/2026-10-15_review/` | [`papers/jma/2026-10-15_review/`](papers/jma/2026-10-15_review/) |
| `history/JMA/2026-10-16_review/` | [`papers/jma/2026-10-16_review/`](papers/jma/2026-10-16_review/) |
| `history/JMA/JMA_SUBMISSION_READY_20260914/` | [`papers/jma/2026-09_submission_ready/`](papers/jma/2026-09_submission_ready/) |
| `history/JMA/submission_jma/` | [`papers/jma/2026-09_submission_jma/`](papers/jma/2026-09_submission_jma/) |

## ECRA

| 旧路径 | 新路径 |
|---|---|
| `history/ECRA/<版本名>/` | [`papers/ecra/<版本名>/`](papers/ecra/)（41 个版本，名称不变） |

## 归档

| 旧路径 | 新路径 |
|---|---|
| `history/early_research/` | [`archive/early_research/`](archive/early_research/) |
| `history/received_evidence/` | [`archive/received_evidence/`](archive/received_evidence/) |
| `history/_organization_20261019/` | [`archive/organization_20261019/`](archive/organization_20261019/) |
| `history/README.md` | [`archive/README_20261019.md`](archive/README_20261019.md) |
| `history/_git_last_state_20261116.txt` | [`archive/_git_last_state_20261116.txt`](archive/_git_last_state_20261116.txt) |

## 已删除的兼容链接

旧布局用目录链接提供 `deliverables/`、`manuscripts/`、`legacy/`，以及 `outputs/`、`research/` 下的一批别名。2026-11-16 全部移除，实际文件都在 `papers/` 对应版本里，不再保留别名。旧文档若引用这些路径，按本页对照即可。

## 未移动

`data/`、`outputs/`、`research/`、`src/`、`scripts/`、`configs/`、`tests/`、`_DEPENDENCIES/`、`.tools/`、`authorizations/`、`protocols/` 位置不变。
