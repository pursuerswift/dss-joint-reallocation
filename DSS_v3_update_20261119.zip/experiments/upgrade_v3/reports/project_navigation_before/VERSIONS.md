# 版本索引

本仓库是「因果定向相对响应定向的增量价值」这条研究线的完整工程：同一研究先后投过 ECRA、JMA，现目标期刊为 **Decision Support Systems（DSS）**。

最后更新：2026-11-16（v2 建立；`current` 指向 v2，R6 转为 `baseline`）。旧路径对照见 [PATH_MAP.md](PATH_MAP.md)。

## 当前版本

**DSS v2**：*Cost-Aware and Certifiable Targeting Upgrades at Fixed Capacity*，2026-11-16 完成，尚未提交。

| 项 | 位置 |
|---|---|
| 当前工作区 | [`papers/dss/v2_c1c2/`](papers/dss/v2_c1c2/)（短入口：[`current/`](current/)） |
| 交付总览 | [`DELIVERY.md`](papers/dss/v2_c1c2/DELIVERY.md) |
| 主文 | [`DSS_v2_draft.docx`](papers/dss/v2_c1c2/manuscript/DSS_v2_draft.docx) · [PDF](papers/dss/v2_c1c2/manuscript/DSS_v2_draft.pdf) |
| 源稿 | [`DSS_v2_full.md`](papers/dss/v2_c1c2/manuscript/DSS_v2_full.md)、`sections/02–11` |
| 投稿材料 | [Highlights](papers/dss/v2_c1c2/manuscript/highlights.md)、[Cover letter](papers/dss/v2_c1c2/manuscript/cover_letter.md)、[投稿清单](papers/dss/v2_c1c2/manuscript/SUBMISSION_CHECKLIST.md) |
| 检查记录 | [`FORMAL_CHECK.md`](papers/dss/v2_c1c2/reports/FORMAL_CHECK.md) |

冻结基线：**DSS R6**（2026-11-12），[`papers/dss/r6/`](papers/dss/r6/)（短入口 [`baseline/`](baseline/)）。v2 只引用 R6 的数字作为 frozen benchmark，不修改 R6。

## 目录结构

```text
00_START_HERE.md    项目入口
VERSIONS.md         本文件：版本谱系与职责
PATH_MAP.md         2026-11-16 重排的旧→新路径对照
current/            目录链接，指向 papers/dss/v2_c1c2
baseline/           目录链接，指向 papers/dss/r6
papers/
  dss/  v2_c1c2（当前）、r6（基线）、r5、planning_20261111
  jma/  2026-09_submission_jma … 2026-11-03_round5（12 个版本节点）
  ecra/ 41 个历史版本
archive/            更早研究、收到的原始材料、归档记录、git reflog
data/               原始数据与少量中间文件
outputs/            历次运行的结果表与汇总
research/           早期研究工具、源数据、报告、展示材料
src/ scripts/ configs/ tests/   跨版本共享代码与配置
_DEPENDENCIES/ .tools/          保留的 Python / 工具环境
authorizations/ protocols/      Hillstrom 扩展实验的授权回执与协议
```

## 版本谱系

```text
2026-09 ~ 10-08   ECRA：31 个版本迭代到最终投稿     papers/ecra/
2026-09           更早的 JMA 投稿准备               papers/jma/2026-09_*
2026-10-14/15/16  JMA 重建与两轮审稿修订            papers/jma/2026-10-1*
2026-10-18        JMA 实质性修订稿                  papers/jma/2026-10-18_revised
2026-10-20        JMA 语言润色与第二轮               papers/jma/2026-10-20_*
2026-10-22        JMA 修订第 1 轮                    papers/jma/2026-10-22_round1
2026-10-22 ~ 11-03 JMA 第 3/4/5 轮、匿名投稿稿       papers/jma/2026-10-22_round3、2026-10-26_round4、2026-11-03_round5
2026-11-11        JMA 拒稿，转投 DSS                 papers/dss/planning_20261111/
2026-11-11/12     DSS R1–R4                         已删除（由 R5、R6 完整覆盖）
2026-11-12        DSS R5                             papers/dss/r5
2026-11-12        DSS R6                             papers/dss/r6（基线）
2026-11-16        DSS v2（成本感知 + 认证前沿）      papers/dss/v2_c1c2（当前）
```

## 版本节点说明

- DSS v2 是当前工作区：方法、实证、仿真、稿件与投稿材料都在其中；R6 冻结为对照基线，R5 保留作更早对照。
- JMA 目录按日期命名：`-18_revised` 是 10-18 修订稿，`-20_*` 是语言润色与第二轮，`-22_round1` 是 10-22 修订（原 `revision_output/`），`-11-03_round5` 是最后送审的匿名稿。
- ECRA 目录沿用原版本名，未按日期重命名——原有名称已经是版本标识，重命名只会增加对不上号的风险。

## 清理记录

### 2026-11-16（第二轮）

| 项 | 释放 | 理由 |
|---|---|---|
| `ecra_full_run_v4_evidence.zip` | 74.7 GB | ECRA 工作区快照，非精选证据；Criteo 发布版存在依结果抽样，不能作为后续因果证据。`delivery/package_manifest.json`（逐文件 SHA-256）与一致性审计已保留 |
| 物理重排 | — | 所有稿件移入 `papers/`，移除 60 余个兼容目录链接；旧路径见 [PATH_MAP.md](PATH_MAP.md) |

结果：**82.9 GB → 8.3 GB**。

### 2026-11-16（第一轮）

| 项 | 释放 |
|---|---|
| `.git/`（仅记录到 10-15，DSS 未入库；reflog 存于 `archive/_git_last_state_20261116.txt`） | 87 GB |
| `data/processed/full_run` 等旧 Criteo 缓存 | 107 GB |
| `revision_output/analysis_runs`、`outputs/*/runs` 等逐次缓存 | 33 GB |
| DSS R1–R4、`research/tmp`、`__pycache__` | 3.4 GB |

合计 **311 GB → 82.9 GB**。脚本与日志在 `scripts/maintenance/`。

未改动：当前 R6 全部内容、R5、JMA 各版本、ECRA 版本目录、原始数据、`research/data`、依赖环境。

## 复现入口

当前稿（v2）在 [`papers/dss/v2_c1c2/`](papers/dss/v2_c1c2/) 下：

```text
python analysis/verify_flow.py
python analysis/run_flow_experiments.py --experiment all
python analysis/verify_sequential.py
python analysis/run_sequential_experiments.py --experiment all
python analysis/certification_frontier.py
python analysis/prepare_gate.py
python analysis/run_e4_cost_aware.py
python analysis/build_manuscript.py
_DEPENDENCIES/document_runtime/python/python.exe analysis/build_docx.py --inline-native
analysis/add_equations.ps1
```

基线与历史对照：R6 在 [`papers/dss/r6/`](papers/dss/r6/)，完整命令见其 [REPRODUCIBILITY.md](papers/dss/r6/REPRODUCIBILITY.md)。环境用 `_DEPENDENCIES/` 或 `.tools/` 里自带的 Python 3.12.14（已装 numpy/pandas）。
