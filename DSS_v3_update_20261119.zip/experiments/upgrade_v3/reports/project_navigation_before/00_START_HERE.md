# 项目入口

一篇论文的完整研究与投稿工程：**固定活动名额下，因果定向（causal targeting）升级的成本与认证决策**。同一研究线先后投过 ECRA、JMA，现目标期刊为 **Decision Support Systems（DSS）**。

## 当前版本

**DSS v2**：*Cost-Aware and Certifiable Targeting Upgrades at Fixed Capacity*，2026-11-16 完成，尚未提交。

- [`papers/dss/v2_c1c2/`](papers/dss/v2_c1c2/) —— 当前工作区（短入口 [`current/`](current/)）
- [交付总览 DELIVERY.md](papers/dss/v2_c1c2/DELIVERY.md)
- [主文 DOCX](papers/dss/v2_c1c2/manuscript/DSS_v2_draft.docx) / [PDF](papers/dss/v2_c1c2/manuscript/DSS_v2_draft.pdf)
- [Highlights](papers/dss/v2_c1c2/manuscript/highlights.md) / [Cover letter](papers/dss/v2_c1c2/manuscript/cover_letter.md) / [投稿清单](papers/dss/v2_c1c2/manuscript/SUBMISSION_CHECKLIST.md)
- [形式检查记录](papers/dss/v2_c1c2/reports/FORMAL_CHECK.md)

## 冻结基线

**DSS R6**（2026-11-12）保留为对照与复现基线，不再修改：

- [`papers/dss/r6/`](papers/dss/r6/)（短入口 [`baseline/`](baseline/)）
- [复现说明](papers/dss/r6/REPRODUCIBILITY.md) / [数据来源与哈希](papers/dss/r6/INPUTS.md)

v2 引用 R6 的数字作为「frozen benchmark」，不重写 R6 的结果。

## 索引

| 文件 | 用途 |
|---|---|
| [VERSIONS.md](VERSIONS.md) | 版本谱系、目录职责、清理记录 |
| [PATH_MAP.md](PATH_MAP.md) | 2026-11-16 重排的旧路径 → 新路径 |
| [DELIVERY.md](papers/dss/v2_c1c2/DELIVERY.md) | v2 交付物、验证状态、复现、限制 |
| [00_START_HERE.md](00_START_HERE.md) | 本页 |

## 目录速查

```text
current/  -> papers/dss/v2_c1c2   当前工作区
baseline/ -> papers/dss/r6        冻结基线
papers/
  dss/  v2_c1c2（当前）、r6（基线）、r5、planning_20261111
  jma/  2026-09 至 2026-11-03 共 12 个版本节点
  ecra/ 41 个历史版本
archive/    更早研究、收到的原始材料、归档记录、git reflog
data/       原始数据
outputs/    历次运行的结果表与汇总
research/   早期研究工具、源数据、报告
src/ scripts/ configs/ tests/   共享代码与配置
_DEPENDENCIES/ .tools/          运行环境（Python 3.12.14）
authorizations/ protocols/      Hillstrom 扩展实验授权与协议
```

## 维护记录

- **2026-11-16**：建立 DSS v2（成本感知替换 + 认证前沿），完成 20 页草稿、原生公式、参考文献与投稿材料；`current` 指向 v2，R6 转为 `baseline`。
- **2026-11-16**：第二轮清理 + 物理重排，**82.9 GB → 8.3 GB**。
- **2026-11-16**：第一轮清理，**311 GB → 82.9 GB**。
- **2026-10-19**：历史版本归档，[查看报告](archive/organization_20261019/cleanup_report.md)。

旧文档里的 `dss_revision_*`、`revision_output_*`、`history/` 等路径均已失效，按 [PATH_MAP.md](PATH_MAP.md) 对照。
