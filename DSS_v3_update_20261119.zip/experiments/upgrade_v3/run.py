"""Run from any directory. Outputs are stored by run ID."""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
import argparse
from datetime import datetime,timezone
import importlib.metadata
import json
from pathlib import Path
import platform
import sys

HERE=Path(__file__).resolve().parent


def manifest(cfg,stage,dest,resume):
    target=dest/'manifest.json'
    record=dict(stage=stage,python=sys.version,platform=platform.platform(),
        packages={name:importlib.metadata.version(name) for name in ['numpy','pandas','scipy','scikit-learn','lightgbm','matplotlib']},
        started_utc=datetime.now(timezone.utc).isoformat(),status='running')
    if target.exists():
        if not resume: raise FileExistsError(f'{target} exists; use a new --run-id or --resume')
        if json.loads((dest/'config.json').read_text())!=cfg:
            raise ValueError('Configuration changed; choose a new run ID')
    dest.mkdir(parents=True,exist_ok=True)
    (dest/'config.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
    target.write_text(json.dumps(record,indent=2),encoding='utf-8')
    return record


def main():
    p=argparse.ArgumentParser()
    p.add_argument('stage',choices=['simulate','empirical','scale','figures','conflict','revision','final_timing','final_focus','all'])
    p.add_argument('--config',default=str(HERE/'config/pilot.json'))
    p.add_argument('--run-id',default='pilot_20261116')
    p.add_argument('--resume',action='store_true')
    p.add_argument('--workers',type=int,default=1,help='Independent simulation worker processes')
    p.add_argument('--smoke',action='store_true')
    args=p.parse_args()
    if Path(args.run_id).name!=args.run_id or args.run_id in ['.','..']:
        raise ValueError('run-id must be a directory name')
    cfg=json.loads(Path(args.config).read_text(encoding='utf-8'))
    if args.smoke:
        cfg['simulations'].update(repetitions=2,sizes=[400])
        cfg['gaussian_draws']=256
        cfg['empirical']['datasets']=['hillstrom']
        cfg['empirical']['cost_scenarios']=cfg['empirical']['cost_scenarios'][:2]
        cfg['scale'].update(total_records=[1000],types=[3],repetitions=1)
    stages=['simulate','empirical','scale','figures'] if args.stage=='all' else [args.stage]
    from threadpoolctl import threadpool_limits
    with threadpool_limits(limits=1):
        for stage in stages:
            dest=HERE/'results'/args.run_id/stage
            rec=manifest(cfg,stage,dest,args.resume)
            try:
                if stage=='simulate':
                    from upgrade.simulation import run
                    run(cfg,dest,args.resume,workers=args.workers)
                elif stage=='empirical':
                    from upgrade.empirical import run
                    run(cfg,dest,args.resume)
                elif stage=='scale':
                    from upgrade.scale import run
                    run(cfg,dest)
                elif stage in ['final_timing','final_focus']:
                    from upgrade.final_revision import run_timing,run_focus
                    (run_timing if stage=='final_timing' else run_focus)(cfg,dest,args.resume,workers=args.workers)
                elif stage=='revision':
                    from upgrade.revision import run
                    run(cfg,dest,args.resume,workers=args.workers)
                elif stage=='conflict':
                    from upgrade.conflict import run
                    run(cfg,dest,args.resume,workers=args.workers)
                else:
                    from upgrade.figures import run
                    run(dest.parent,dest)
                rec.update(status='complete',finished_utc=datetime.now(timezone.utc).isoformat())
            except BaseException as exc:
                rec.update(status='failed',error=repr(exc))
                raise
            finally:
                (dest/'manifest.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')


if __name__=='__main__': main()
