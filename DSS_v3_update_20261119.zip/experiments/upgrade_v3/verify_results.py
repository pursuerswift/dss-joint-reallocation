"""Validate completed experiment artifacts without modifying their values."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run-id',default='release_20261116')
    args=parser.parse_args();root=HERE/'results'/args.run_id;checks={}
    def require(name,condition):
        checks[name]=bool(condition)
        if not condition: raise AssertionError(name)
    if (root/'final_timing').exists():
        folder=root/'final_timing';d=pd.read_csv(folder/'runtime.csv');v=pd.read_csv(folder/'frontiers.csv')
        cfg=json.loads((folder/'config.json').read_text())
        require('timing_complete',json.loads((folder/'manifest.json').read_text())['status']=='complete')
        expected=(len(cfg['sizes'])*len(cfg['types'])+1)*cfg['timing_repetitions']*4
        require('timing_coverage',len(d)==expected)
        require('timing_population',(d.n==d.entrants+d.incumbents).all())
        w=v.pivot(index=['family','n','k','rep','cap'],columns='method',values='objective')
        require('frontier_dominance',(w.type_flow>=w.score_stopping-1e-7).all())
        x=d.pivot(index=['family','n','k','rep','method'],columns='mode',values='objective')
        require('output_modes_equal',np.allclose(x.plan,x.frontier,atol=1e-8))
        folder=root/'final_focus';d=pd.read_csv(folder/'replicates.csv')
        require('focus_complete',json.loads((folder/'manifest.json').read_text())['status']=='complete')
        require('focus_coverage',len(d)==7*cfg['focus_repetitions']*4*5)
        require('focus_identity',np.allclose(d.true_net,d.gross-d.cost,atol=1e-8))
        require('focus_cap',(d.exchanges<=d.cap).all())
        (root/'validation.json').write_text(json.dumps(checks,indent=2))
        print(json.dumps(checks,indent=2));return
    if (root/'revision').exists():
        from upgrade.revision import KEYS
        folder=root/'revision';d=pd.read_csv(folder/'replicates.csv')
        require('complete',json.loads((folder/'manifest.json').read_text())['status']=='complete')
        require('unique',not d.duplicated(KEYS+['rep','method']).any())
        require('net_identity',np.allclose(d.true_net,d.gross-d.cost,atol=1e-8))
        require('cap',(d.exchanges<=d.cap).all())
        w=d.pivot(index=KEYS+['rep'],columns='method',values='predicted_net')
        design=json.loads((folder/'cells_design.json').read_text())
        require('coverage',len(d)==sum(reps for _,reps in design)*4*5 and not w.isna().any().any())
        require('exact_dominance',(w.type_flow-w[['score_original','score_stopping','greedy_rematch']].max(axis=1)>=-1e-6).all())
        require('stopping_dominance',(w.score_stopping>=w.score_original-1e-6).all())
        require('retention_option',(w.score_stopping>=-1e-6).all())
        print(json.dumps(checks,indent=2));return
    if (root/'conflict').exists():
        folder=root/'conflict'
        cfg=json.loads((folder/'config.json').read_text())
        require('conflict_complete',json.loads((folder/'manifest.json').read_text())['status']=='complete')
        df=pd.read_csv(folder/'replicates.csv')
        keys=['family','n','types','strength','noise','cap_share','rep']
        expected=np.prod([len(cfg[k]) for k in ['families','sizes','types','strengths','score_noise','cap_shares']])*cfg['repetitions']
        require('conflict_unique',not df.duplicated(keys+['method']).any())
        wide=df.pivot(index=keys,columns='method',values='predicted_net_per_1000')
        require('conflict_coverage',len(wide)==expected and len(df)==expected*3 and not wide.isna().any().any())
        require('conflict_exact_reference',np.allclose(wide.type_flow,wide.generic_lp,atol=1e-6,rtol=0))
        require('conflict_greedy_bound',(wide.type_flow-wide.greedy_rematch>=-1e-6).all())
        require('conflict_net_identity',np.allclose(df.true_net_per_1000,df.gross_per_1000-df.cost_per_1000,atol=1e-8,rtol=0))
        require('conflict_cap',((df.exchanges>=0)&(df.exchanges<=df.cap)).all())
        flow=df[df.method=='type_flow']
        require('conflict_reverse_counts',((flow.reverse_augmentations>=0)&(flow.reverse_augmentations<=flow.exchanges)&(flow.reverse_arc_traversals>=flow.reverse_augmentations)).all())
        out=dict(status='PASS',checks=checks,paired_budget_records=int(expected),method_rows=len(df))
        (root/'validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        print(json.dumps(out,indent=2))
        return
    for stage in ['simulate','empirical','scale','figures']:
        folder=root/stage;meta=json.loads((folder/'manifest.json').read_text())
        require(stage+'_complete',meta['status']=='complete')
    sim=pd.read_csv(root/'simulate/replicates.csv',keep_default_na=False)
    cfg=json.loads((root/'simulate/config.json').read_text())
    nreps=cfg['simulations']['repetitions']*len(cfg['simulations']['sizes'])*len(cfg['simulations']['regimes'])
    require('simulation_repetitions',len(sim)==nreps*6*3)
    require('simulation_regimes',set(sim.regime)==set(cfg['simulations']['regimes']))
    require('simulation_nonnegative_regret',(sim.regret>=-1e-9).all())
    require('simulation_probabilities',sim.adopted.isin([0,1]).all() and sim.harm.isin([0,1]).all())
    for name in ['gate_candidates','test_candidates']:
        df=pd.read_csv(root/'empirical'/f'{name}.csv')
        require(name+'_net_identity',np.allclose(df.net,df.gross-df.cost,atol=1e-12,rtol=0))
        require(name+'_retention',(df.loc[df.method=='retain','net']==0).all())
        require(name+'_unique',not df.duplicated(['dataset','seed','scenario','key']).any())
    for folder in (root/'empirical').iterdir():
        if not folder.is_dir() or not (folder/'complete.json').exists(): continue
        with np.load(folder/'split_ids.npz') as ids:
            require(folder.name+'_disjoint',all(np.intersect1d(ids[a],ids[b]).size==0 for a in ids.files for b in ids.files if a<b))
        decisions=pd.read_csv(folder/'frozen_decision_test.csv')
        require(folder.name+'_adoption_lcb',((decisions.key=='retain') | (decisions.gate_lcb>0)).all())
    scale=pd.read_csv(root/'scale/runtime.csv')
    require('scale_population_identity',(scale.total_records==scale.entrant_pool+scale.incumbent_places).all())
    require('scale_cap',(scale.actual_exchanges<=scale.exchange_cap).all())
    if (root/'coupling/replicates.csv').exists():
        c=pd.read_csv(root/'coupling/replicates.csv')
        design=json.loads((root/'coupling/design.json').read_text())
        require('coupling_repetitions',len(c)==len(design['sizes'])*len(design['couplings'])*design['repetitions']*5)
        require('coupling_net_identity',np.allclose(c.true_net_per_1000,c.gross_per_1000-c.cost_per_1000))
        require('coupling_oracle_bound',(c.regret_per_1000>=-1e-8).all())
    if (root/'penalty_path/candidate_values.csv').exists():
        p=pd.read_csv(root/'penalty_path/candidate_values.csv')
        require('penalty_net_identity',np.allclose(p.net,p.gross-p.cost))
        for role in ['gate','test']:
            base=pd.read_csv(root/'empirical'/f'{role}_candidates.csv')
            merged=p[(p.penalty==0)&(p.role==role)].merge(base[base.method=='cost_flow'],
                on=['dataset','seed','scenario','cap'],suffixes=('_penalty','_base'),validate='one_to_one')
            require('penalty_zero_'+role,len(merged)==len(p[(p.penalty==0)&(p.role==role)]) and
                    np.allclose(merged.net_penalty,merged.net_base) and
                    (merged.exchanges_penalty==merged.exchanges_base).all())
    require('figures_present',all((root/'figures'/f'{name}.{ext}').exists() for name in
        ['simulation_net_value','simulation_adoption','empirical_candidate_values','flow_scaling'] for ext in ['png','svg']))
    out=dict(status='PASS',checks=checks,simulation_repetitions=nreps,simulation_decision_rows=len(sim))
    (root/'validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))


if __name__=='__main__': main()
