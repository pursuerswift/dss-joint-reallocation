# 成本与证据感知的名单升级实验

## 2026-11-19 投稿前定向增强

当前补充运行：`results/submission_final_20261119`。计时在85个实例上顺序执行340次求解，比较最终方案及完整标量价值前沿；七个聚焦单元各100次重复，共14,000条方法预算记录。请先完成计时，再运行并行仿真。

```powershell
& ./.tools/extension_v2_conda_clean/python.exe ./current/run.py final_timing --config ./current/config/final_revision.json --run-id final_new
& ./.tools/extension_v2_conda_clean/python.exe ./current/run.py final_focus --config ./current/config/final_revision.json --run-id final_new --workers 4
& ./.tools/extension_v2_conda_clean/python.exe ./current/verify_results.py --run-id final_new
& ./.tools/extension_v2_conda_clean/python.exe ./current/final_outputs.py
```

`final_outputs.py`生成锁定运行submission_final_20261119的投稿表格及重点置信区间图；修改运行入口可复用新结果。原热力图仍对应20次重复，新表对应100次重复，包含原前20次。完整前沿指全部整数预算的目标值及一个最终方案，不意味着输出所有预算的个体配对清单。`final_manuscript.py`是已执行的一次性稿件迁移，不应重复执行。

## 2026-11-18 Major revision

新增内生停止排序基线、94格配对实验和独立实例计时。完整结果在 `results/major_revision_20261118/`；主文和三份修订报告位于 `papers/dss/v3_joint_reallocation/`。原始结果保持可追溯。

```powershell
& ./.tools/extension_v2_conda_clean/python.exe ./current/run.py revision --config ./current/config/major_revision.json --run-id major_revision_new --workers 4
& ./.tools/extension_v2_conda_clean/python.exe ./current/verify_results.py --run-id major_revision_new
& ./.tools/extension_v2_conda_clean/python.exe ./current/revision_outputs.py --run-id major_revision_new
& ./.tools/extension_v2_conda_clean/python.exe ./current/revision_benchmark.py --run-id major_revision_new
& ./.tools/extension_v2_conda_clean/python.exe -m unittest discover -s ./experiments/upgrade_v3/tests -t ./experiments/upgrade_v3 -v
& ./.tools/extension_v2_conda_clean/python.exe ./papers/dss/v3_joint_reallocation/build_manuscript.py
```

`revision_outputs.py`从指定运行生成图表，并更新稿件目录的对应图。`revision_reports.py`生成本次已锁定运行的报告与补充表；`revise_manuscript_20261118.py`是已执行的一次性编辑迁移，不应重复执行。计时脚本 `revision_benchmark.py`独立执行，避免与其他计算争用资源。原历史模型未重新训练，其分割、冻结和既有结果已重新校验。新结果尚未推送远程仓库。

当前活动版本为v3。研究重点是在固定名额和转换成本下，联合选择交换对象与配对，并用评估数据调节替换规模。实验同时衡量方案本身的净收益与实际采纳收益。

本版本已经实现完整实验管线。2026-11-17进入聚焦补充实验与英文初稿阶段：主线为联合选择与转接配对的净收益价值，新增结构对照和独立精确求解器比较。稿件入口为 `papers/dss/v3_joint_reallocation/README.md`；新增结果见 [补充实验报告](reports/JOINT_FOLLOWUP_20261117.md)。

## 本轮资源竞争实验

2026-11-17新增48格资源竞争实验：1,440组重复、四档预算、5,760组配对评价。运行revision_v3_20261117已完成；[结果报告](reports/REVISION_CONFLICT_20261117.md)给出贪心/精确差距、评分噪声和反向弧诊断。当前论文已扩充为24页主文、10页补充材料、39项参考文献，历史评价进入主文第6节。

```powershell
& ./.tools/extension_v2_conda_clean/python.exe ./current/run.py conflict --config ./current/config/revision_conflict.json --run-id conflict_new_run --workers 4
& ./.tools/extension_v2_conda_clean/python.exe ./current/verify_results.py --run-id conflict_new_run
```

## 快速运行

在项目根目录运行，使用已经安装的Python环境。

```powershell
# 默认pilot全流程，自动生成一个新结果目录
.\current\run.ps1

# 指定实验和结果版本
.\current\run.ps1 -Stage all -Profile pilot -RunId my_pilot

# 扩大重复次数、样本规模与数据划分
.\current\run.ps1 -Stage all -Profile full -RunId expanded_v3 -Workers 4

# 相同方法与配置下恢复已完成的单元
.\current\run.ps1 -Stage all -Profile full -RunId expanded_v3 -Workers 4 -Resume

# 单独运行核心测试和结果校验
& .\.tools\extension_v2_conda_clean\python.exe -m unittest discover -s .\experiments\upgrade_v3\tests -t .\experiments\upgrade_v3 -v
& .\.tools\extension_v2_conda_clean\python.exe .\current\verify_results.py --run-id expanded_v3

# 已完成真实数据实验后，绘制五档方差惩罚的响应曲线
& .\.tools\extension_v2_conda_clean\python.exe .\current\penalty_path.py --run-id expanded_v3

# 独立研究非可分转接成本对名单选择的作用
& .\.tools\extension_v2_conda_clean\python.exe .\current\coupling_experiment.py --run-id expanded_v3 --workers 2

# 三类成本机制与独立精确求解器比较；新运行使用新名称
& .\.tools\extension_v2_conda_clean\python.exe .\current\joint_followup.py all --run-id joint_new_run --workers 4
& .\.tools\extension_v2_conda_clean\python.exe .\current\joint_figures.py --run-id joint_new_run
```

测试也可以在本目录运行 `python -m unittest discover -s tests -v`。若原始数据另放到项目根目录，设置 `CAUSAL_PROJECT_ROOT` 指向该根目录。四个原始输入的路径由 `upgrade/data.py` 管理，使用现有R6存放的公开源数据。`-Workers` 指定独立仿真的并行进程数，默认1；每次重复的随机种子不受进程数影响。规模计时应单独运行。

## 实验组成

| 模块 | 内容 |
|---|---|
| `upgrade/flow.py` | 精确类型成本流、势函数Dijkstra、全局配对索引、各上限快照 |
| `upgrade/policies.py` | 分数路径、均值成本、可分成本、完整成本流、证据感知流 |
| `upgrade/inference.py` | AIPW净收益、统一同时门控、支持范围界、净收益样本规划 |
| `upgrade/data.py` | 数据读取与划分、训练内交叉拟合DR、调参选择、类型边界 |
| `upgrade/simulation.py` | 六种已知真值机制、逐重复配对输出、实际采用净收益 |
| `upgrade/empirical.py` | 三个队列的门控冻结与测试评价、成本情景、配对对照 |
| `upgrade/scale.py` | 真实总人群数与交换次数分开记录的规模实验 |
| `upgrade/comparators.py` | 独立紧凑网络LP、完整成本贪心后重配对 |
| `joint_followup.py` | 三类转接成本、两类比例、噪声对照与顺序求解器计时 |
| `joint_figures.py` | 论文主图：价值分解、结构覆盖、计算规模、残量交换示例 |
| `upgrade/figures.py` | 净收益、采纳率、真实队列比较和规模图，PNG/SVG |
| `tests/` | 索引回归、枚举最优性、重配对、净收益功效与数据生成等测试 |

数学与实验设计见 [PROTOCOL.md](PROTOCOL.md)，主题与期刊路线见 [RESEARCH_DIRECTION.md](RESEARCH_DIRECTION.md)。最新验证运行和结果解读见 [reports/EXPERIMENT_STATUS.md](reports/EXPERIMENT_STATUS.md)。

## 结果组织

`results/<run-id>/` 下保存实验配置、随机种子、软件版本和全部情景结果。更换方法或配置时使用新run-id；不进行哈希校验或重复保存代码快照。正式结果版本以 `results/ACTIVE_RUN.json` 为入口。带`smoke`、`pilot_v3`或早期`pilot_20261116`名称的目录属于开发试运行；`release_20261116` 为先导实验，当前已完成结果为 `expanded_v3`。再次开展新运行时请更换run-id。

- `simulate/replicates.csv` 保留每次重复、每种方法及每种门控的结果。
- `simulate/summary.csv` 汇总真实净收益、采纳率、错误采用和蒙特卡洛误差。
- `simulate/paired_contrasts.csv` 是相同随机数据下的方法差异。
- `empirical/gate_candidates.csv` 同列毛收益、成本、净收益、标准误和同时下界。
- `empirical/frozen_decision_test.csv` 记录冻结选择的测试队列收益。
- `empirical/test_candidates.csv` 和 `test_paired_contrasts.csv` 是预定义方法诊断，未用于重新选择门控方案。
- `empirical/net_power_frontier.csv` 使用声明的毛收益目标与净收益采纳阈值规划样本。
- `scale/runtime.csv` 记录总人数、候选池、现有名额、上限与实际交换数。
- `penalty_path/` 比较五档固定方差惩罚的候选收益、交换量和采纳结果。这是独立于主实验的探索性机制分析，保留全部档位。
- `coupling/` 固定收益分布，逐步增加不兼容转接成本，比较联合选择与最优重配对后的排序基线。此处的配对差异为完整成本流减各比较器。
- 独立补充运行 `joint_v3_20261117` 的 `mechanisms/` 保存1,800组情景重复和六种方法结果，`benchmark/` 保存两个精确求解器的54条计时，`figures/` 保存四组论文图。

## 与v2的关系

v2保留为已评估历史版本，其正文和投稿包仍对应修订前的计算与论证。v3以新的评价器和实验协议替代活动研究流程。已知E4索引错误在v3中由全局配对索引与专门回归测试解决，旧结果的正确索引复算保存在 `papers/dss/v2_c1c2/review_20261116/e4_index_audit.csv`。需要复查历史数值时使用该表，不将旧投稿包视为当前成果。
