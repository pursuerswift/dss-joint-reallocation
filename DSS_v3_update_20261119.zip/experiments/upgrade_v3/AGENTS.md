# Active research instructions

- This is the active experimental research version. On 2026-11-17 the user authorized focused follow-up experiments and manuscript drafting under the press-release principle. Drafts belong in papers/dss/v3_joint_reallocation; retain the historical manuscripts.
- Focus work on a clear research capability and its mechanism. Preserve complete experiment outputs and choose conclusions supported by those outputs. Avoid reviewer-style defensive checklists as the research narrative.
- Original source data and historical manuscript versions remain reference material. Use versioned run directories for new results.
- Exposed exchange pairs always use global record indices. Verify net gain = paired gross gain - actual transition cost - applicable fixed cost.
- Generate candidates from features and train/tune predictions. Freeze gate decisions before test evaluation. Test diagnostics do not reopen selection.
- Use `run.ps1` or `run.py`. Core tests are `python -m unittest discover -s tests -v`; completed run checks are `python verify_results.py --run-id <id>`.
- Preserve experiment configuration, random seeds and all scenario results. Use a new run ID when changing the method/config. Do not add hashes or repeated code snapshots; focus checks on research calculations and experimental design.
- Runtime observations use total population, both pool sizes, requested cap and actual exchange count explicitly.
