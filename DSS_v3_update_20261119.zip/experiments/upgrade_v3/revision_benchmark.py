"""Sequential timing on independently regenerated instances (single BLAS thread)."""
import json,time,platform
from pathlib import Path
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from upgrade.flow import topk,solve_path
from upgrade.comparators import generic_lp

def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--run-id',required=True)
    args=parser.parse_args()
    if Path(args.run_id).name!=args.run_id or args.run_id in ['.','..']:raise ValueError('Invalid run ID')
    dest=Path(__file__).resolve().parent/'results'/args.run_id/'benchmark'
    if (dest/'runtime.csv').exists():raise FileExistsError('Choose a new run ID for new timing results')
    dest.mkdir(parents=True,exist_ok=True);rows=[]
    with threadpool_limits(limits=1):
        for n in [2000,10000]:
            for k in [3,12,25]:
                for rep in range(5):
                    rng=np.random.default_rng(np.random.SeedSequence([20261118,n,k,rep]))
                    s=rng.normal(0,.1,n);b=topk(rng.normal(size=n),np.arange(n),.2)
                    t=rng.integers(k,size=n);g=rng.uniform(.005,.025,(k,k));cap=int(b.sum()*.5)
                    for method in (['flow','lp'] if rep%2==0 else ['lp','flow']):
                        start=time.perf_counter()
                        p=solve_path(s,b,t,g,[cap])[cap] if method=='flow' else generic_lp(s,b,t,g,cap)
                        rows.append(dict(n=n,k=k,rep=rep,method=method,seconds=time.perf_counter()-start,cap=cap,exchanges=p.m,objective=p.objective))
                print(n,k,flush=True)
    d=pd.DataFrame(rows);d.to_csv(dest/'runtime.csv',index=False)
    w=d.pivot(index=['n','k','rep'],columns='method',values='objective')
    assert np.max(abs(w.flow-w.lp))<1e-6
    (dest/'design.json').write_text(json.dumps(dict(seed=20261118,repetitions=5,independent_instances=True,platform=platform.platform(),max_gap=float(np.max(abs(w.flow-w.lp)))),indent=2))
if __name__=='__main__':main()
